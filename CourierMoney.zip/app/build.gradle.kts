plugins {
    id("com.android.application")
}

android {
    namespace = "ru.courier.money"
    compileSdk = 36

    defaultConfig {
        applicationId = "ru.courier.money"
        minSdk = 23
        targetSdk = 36
        versionCode = 17
        versionName = "2.9.0"

        // The API key is injected by GitHub Actions from the ORS_API_KEY secret.
        // No real key is stored in the source archive.
        val orsApiKey = System.getenv("ORS_API_KEY") ?: ""
        val escaped = orsApiKey.replace("\\", "\\\\").replace("\"", "\\\"")
        buildConfigField("String", "ORS_API_KEY", "\"$escaped\"")
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
