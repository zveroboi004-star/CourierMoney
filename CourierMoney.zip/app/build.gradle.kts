plugins {
    id("com.android.application")
}

android {
    namespace = "ru.courier.money"
    compileSdk = 36

    defaultConfig {
        applicationId = "ru.courier.money"
        minSdk = 23
        targetSdk = 36
        versionCode = 2
        versionName = "1.1"

        // GitHub Actions passes ORS_API_KEY through a Gradle project property.
        // The value is embedded in this private APK so the app can work
        // immediately after installation; the Settings screen can still
        // override it locally.
        val orsApiKey = providers.gradleProperty("ORS_API_KEY").orElse("").get()
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "")
            .replace("\r", "")
        buildConfigField("String", "ORS_API_KEY", "\"$orsApiKey\"")
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
