package ru.courier.money

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.toMutablePreferences
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

private val Context.dataStore by preferencesDataStore("courier_money")

data class Order(
    val amount: Double,
    val bonus: Double,
    val km: Double,
    val minutes: Int,
    val timestamp: Long
) {
    val total get() = amount + bonus
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CourierMoneyV2() }
    }
}

@Composable
fun CourierMoneyV2() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var orders by remember { mutableStateOf<List<Order>>(emptyList()) }
    var fuelCostPerKm by remember { mutableStateOf(0.0) }
    var showAdd by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        runCatching {
            val p = context.dataStore.data.first()
            orders = decodeOrders(p[ORDERS_KEY])
            fuelCostPerKm = p[FUEL_KEY]?.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
        }
    }

    fun save(newOrders: List<Order>, newFuel: Double = fuelCostPerKm) {
        orders = newOrders
        fuelCostPerKm = newFuel
        scope.launch {
            context.dataStore.updateData {
                it.toMutablePreferences().apply {
                    this[ORDERS_KEY] = encodeOrders(newOrders)
                    this[FUEL_KEY] = newFuel.toString()
                }
            }
        }
    }

    val total = orders.sumOf { it.total }
    val km = orders.sumOf { it.km }
    val minutes = orders.sumOf { it.minutes }
    val fuel = km * fuelCostPerKm
    val net = total - fuel
    val avg = if (orders.isEmpty()) 0.0 else total / orders.size
    val perKm = if (km > 0) net / km else 0.0
    val perHour = if (minutes > 0) net / (minutes / 60.0) else 0.0

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("Courier Money V2") }) },
            floatingActionButton = {
                FloatingActionButton(onClick = { showAdd = true }) { Text("+") }
            }
        ) { pad ->
            Column(Modifier.padding(pad).padding(16.dp).fillMaxSize()) {
                Text("Сегодня", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(8.dp))
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text(money(net), style = MaterialTheme.typography.headlineLarge)
                        Text("чистыми • ${orders.size} заказов")
                        Spacer(Modifier.height(12.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Metric("Средний", money(avg))
                            Metric("₽/км", "%.1f".format(perKm))
                            Metric("₽/час", "%.0f".format(perHour))
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("Валовая сумма: ${money(total)}")
                        Text("Топливо: ${money(fuel)}")
                    }
                }
                Spacer(Modifier.height(14.dp))
                OutlinedButton(onClick = {
                    val next = if (fuelCostPerKm == 0.0) 8.0 else 0.0
                    save(orders, next)
                }) {
                    Text("Топливо: ${"%.1f".format(fuelCostPerKm)} ₽/км")
                }
                Spacer(Modifier.height(12.dp))
                Text("Заказы", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                if (orders.isEmpty()) {
                    Text("Пока нет заказов. Нажми +.")
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(orders.reversed()) { o ->
                            val score = if (o.minutes > 0) o.total / (o.minutes / 60.0) else 0.0
                            Card(Modifier.fillMaxWidth()) {
                                Row(
                                    Modifier.padding(14.dp).fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(money(o.total), style = MaterialTheme.typography.titleLarge)
                                        Text("${"%.1f".format(o.km)} км • ${o.minutes} мин")
                                        if (o.bonus > 0) Text("Бонус: ${money(o.bonus)}")
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("${"%.0f".format(score)} ₽/ч")
                                        Text(if (score >= 450) "ВЫГОДНЫЙ" else "обычный")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (showAdd) {
            AddOrderDialog(
                onDismiss = { showAdd = false },
                onAdd = {
                    save(orders + it)
                    showAdd = false
                }
            )
        }
    }
}

@Composable
fun Metric(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleMedium)
        Text(label, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun AddOrderDialog(onDismiss: () -> Unit, onAdd: (Order) -> Unit) {
    var amount by remember { mutableStateOf("") }
    var bonus by remember { mutableStateOf("") }
    var km by remember { mutableStateOf("") }
    var minutes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Добавить заказ") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it },
                    label = { Text("Сумма, ₽") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true
                )
                OutlinedTextField(
                    value = bonus,
                    onValueChange = { bonus = it },
                    label = { Text("Бонус/доплата, ₽") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true
                )
                OutlinedTextField(
                    value = km,
                    onValueChange = { km = it },
                    label = { Text("Километры") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true
                )
                OutlinedTextField(
                    value = minutes,
                    onValueChange = { minutes = it },
                    label = { Text("Время, минут") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                val a = amount.num()
                val b = bonus.num()
                val k = km.num()
                val m = minutes.toIntOrNull()?.coerceAtLeast(0) ?: 0
                if (a > 0 && b >= 0 && k >= 0 && m >= 0) {
                    onAdd(Order(a, b, k, m, System.currentTimeMillis()))
                }
            }) { Text("Добавить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

private fun String.num() = replace(",", ".").toDoubleOrNull() ?: 0.0
private fun money(v: Double) = "${"%.0f".format(Locale.US, v)} ₽"

private val ORDERS_KEY = stringPreferencesKey("orders")
private val FUEL_KEY = stringPreferencesKey("fuel")

private fun encodeOrders(list: List<Order>): String {
    val a = JSONArray()
    list.forEach {
        a.put(JSONObject().apply {
            put("amount", it.amount)
            put("bonus", it.bonus)
            put("km", it.km)
            put("minutes", it.minutes)
            put("timestamp", it.timestamp)
        })
    }
    return a.toString()
}

private fun decodeOrders(s: String?): List<Order> {
    if (s.isNullOrBlank()) return emptyList()
    return runCatching {
        val a = JSONArray(s)
        (0 until a.length()).mapNotNull { index ->
            runCatching {
                val o = a.getJSONObject(index)
                val amount = o.optDouble("amount", 0.0)
                val bonus = o.optDouble("bonus", 0.0)
                val km = o.optDouble("km", 0.0)
                val minutes = o.optInt("minutes", 0)
                val timestamp = o.optLong("timestamp", 0L)
                if (amount <= 0.0 || bonus < 0.0 || km < 0.0 || minutes < 0) return@runCatching null
                Order(amount, bonus, km, minutes, timestamp)
            }.getOrNull()
        }
    }.getOrElse { emptyList() }
}