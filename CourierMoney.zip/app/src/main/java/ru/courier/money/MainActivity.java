package ru.courier.money;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String PREFS = "courier_money";
    private static final String ORDERS = "orders";
    private static final String PICKUP_FEE = "pickup_fee";
    private static final String DELIVERY_FEE = "delivery_fee";
    private static final String PRICE_PER_KM = "price_per_km";
    private static final String RATING = "rating";
    private static final String RATING_5 = "rating_5";
    private static final String RATING_475 = "rating_475";
    private static final String RATING_450 = "rating_450";
    private static final String RATING_425 = "rating_425";
    private static final String CITY = "city";
    private static final String ORS_ROUTING_BASE = "https://api.heigit.org/openrouteservice";
    private static final String ORS_GEOCODE_BASE = "https://api.heigit.org/pelias/v1";
    private static final String NOMINATIM_BASE = "https://nominatim.openstreetmap.org/search";
    private static final String PHOTON_BASE = "https://photon.komoot.io/api/";

    private final List<Order> orders = new ArrayList<>();
    private final DecimalFormat moneyFormat = new DecimalFormat("0.##");
    private final DecimalFormat kmFormat = new DecimalFormat("0.0");
    private final ExecutorService executor = Executors.newFixedThreadPool(3);
    private final ExecutorService geocodeExecutor = Executors.newFixedThreadPool(4);
    private SharedPreferences prefs;
    private LinearLayout orderContainer;
    private TextView summary;

    private double pickupFee;
    private double deliveryFee;
    private double pricePerKm;
    private double rating;
    private double rating5;
    private double rating475;
    private double rating450;
    private double rating425;
    private String city;

    private static final Store[] STORES = new Store[]{
            new Store("Пятёрочка №1", "проспект Ленина, 20", 55.371106, 39.058016),
            new Store("Пятёрочка №2", "4-й микрорайон, 21А", 55.364266, 39.061747),
            new Store("Пятёрочка №3", "ул. Спортивная, 15Б", 55.369144, 39.074362)
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        loadTariff();
        loadOrders();
        buildUi();
        refreshUi();
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        geocodeExecutor.shutdownNow();
        super.onDestroy();
    }

    private void loadTariff() {
        pickupFee = parseNonNegative(prefs.getString(PICKUP_FEE, "70"), 70);
        deliveryFee = parseNonNegative(prefs.getString(DELIVERY_FEE, "105"), 105);
        pricePerKm = parseNonNegative(prefs.getString(PRICE_PER_KM, "30"), 30);
        rating = clamp(parseNumber(prefs.getString(RATING, "5.0"), 5.0), 0, 5);
        rating5 = parseNonNegative(prefs.getString(RATING_5, "25"), 25);
        rating475 = parseNonNegative(prefs.getString(RATING_475, "20"), 20);
        rating450 = parseNonNegative(prefs.getString(RATING_450, "10"), 10);
        rating425 = parseNonNegative(prefs.getString(RATING_425, "5"), 5);
        city = prefs.getString(CITY, "Егорьевск");
        if (city == null || city.trim().isEmpty()) city = "Егорьевск";
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(12), dp(16), dp(12));

        root.addView(text("🚴 Courier Money", 26, true), matchWrap());
        root.addView(text("💰 Учёт заработка курьера", 15, false), matchWrap());

        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER_VERTICAL);

        Button add = button("➕ Заказ");
        add.setOnClickListener(v -> showAddDialog());
        controls.addView(add, weightWrap(1));

        Button settings = button("⚙️ Настройки");
        settings.setOnClickListener(v -> showSettingsDialog());
        controls.addView(settings, weightWrap(1));

        Button clear = button("🧹 Очистить");
        clear.setOnClickListener(v -> confirmClear());
        controls.addView(clear, weightWrap(1));

        root.addView(controls, matchWrap());

        summary = text("", 16, true);
        summary.setPadding(0, dp(14), 0, dp(8));
        root.addView(summary, matchWrap());

        TextView ordersTitle = text("📋 Заказы", 20, true);
        ordersTitle.setPadding(0, dp(16), 0, dp(8));
        root.addView(ordersTitle, matchWrap());

        ScrollView scroll = new ScrollView(this);
        orderContainer = new LinearLayout(this);
        orderContainer.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(orderContainer);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        setContentView(root);
    }

    private void refreshUi() {
        double total = 0;
        double km = 0;
        for (Order o : orders) {
            total += o.total;
            km += o.km;
        }

        summary.setText(
                "💵 Заработано: " + money(total) + " ₽\n" +
                "📦 Заказов: " + orders.size() + " • 🚗 " + km(km) + " км по дорогам\n" +
                "⚙️ Тариф: забор " + money(pickupFee) + " ₽ + выдача " + money(deliveryFee) + " ₽ + " + money(pricePerKm) + " ₽/км • ⭐ " + ratingText(rating)
        );

        orderContainer.removeAllViews();
        List<Order> reversed = new ArrayList<>(orders);
        Collections.reverse(reversed);

        if (reversed.isEmpty()) {
            TextView empty = text("📭 Пока нет заказов.\nНажми «➕ Заказ», чтобы добавить первый.", 16, false);
            empty.setPadding(dp(4), dp(12), dp(4), dp(12));
            orderContainer.addView(empty, matchWrap());
            return;
        }

        for (Order o : reversed) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(14), dp(12), dp(14), dp(12));
            card.setBackgroundResource(android.R.drawable.dialog_holo_light_frame);

            TextView amount = text("💰 " + money(o.total) + " ₽", 20, true);
            card.addView(amount, matchWrap());
            card.addView(text("🏪 " + o.storeName, 15, true), matchWrap());
            card.addView(text("📍 " + o.address, 15, false), matchWrap());
            card.addView(text("🚗 " + km(o.km) + " км по дорогам  •  ⏱️ " + o.minutes + " мин", 15, false), matchWrap());
            card.addView(text((o.isMulti ? "🔗 Мультизаказ" : "📦 Обычный заказ") + "  •  ⭐ Рейтинг " + ratingText(o.rating) + "  •  доплата " + money(o.ratingBonus) + " ₽", 14, false), matchWrap());

            LinearLayout.LayoutParams cp = matchWrap();
            cp.setMargins(0, 0, 0, dp(8));
            orderContainer.addView(card, cp);

            LinearLayout actions = new LinearLayout(this);
            actions.setOrientation(LinearLayout.HORIZONTAL);

            Button edit = button("✏️ Изменить");
            edit.setOnClickListener(v -> showEditOrderDialog(o));
            actions.addView(edit, weightWrap(1));

            if (o.lat != 0 && o.lon != 0) {
                Button routes = button("🗺️ Маршруты");
                routes.setOnClickListener(v -> showRouteAlternatives(o));
                actions.addView(routes, weightWrap(1));

                Button nav = button("🧭 Навигатор");
                nav.setOnClickListener(v -> openNavigator(routeStartForOrder(o), o.lat, o.lon));
                actions.addView(nav, weightWrap(1));
            }

            orderContainer.addView(actions, cp);
        }
    }

    private void showAddDialog() {
        final LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), 0, dp(20), 0);

        TextView selected = text("🏪 Выбери магазин", 17, true);
        box.addView(selected, matchWrap());
        final Store[] chosen = {null};

        for (Store s : STORES) {
            Button b = button("🏪 " + s.name + "\n" + s.address);
            b.setOnClickListener(v -> {
                chosen[0] = s;
                selected.setText("✅ " + s.name + "\n" + s.address);
            });
            box.addView(b, matchWrap());
        }

        TextView multiTitle = text("📦 Адреса клиентов", 17, true);
        multiTitle.setPadding(0, dp(10), 0, dp(4));
        box.addView(multiTitle, matchWrap());

        LinearLayout addressRows = new LinearLayout(this);
        addressRows.setOrientation(LinearLayout.VERTICAL);
        box.addView(addressRows, matchWrap());

        final List<EditText> addressFields = new ArrayList<>();
        final List<CheckBox> multiChecks = new ArrayList<>();

        Runnable addAddressRow = new Runnable() {
            @Override public void run() {
                final int index = addressFields.size();
                LinearLayout row = new LinearLayout(MainActivity.this);
                row.setOrientation(LinearLayout.VERTICAL);
                row.setPadding(0, dp(3), 0, dp(3));

                EditText address = field("📍 Адрес клиента " + (index + 1), false);
                address.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
                row.addView(address, matchWrap());

                CheckBox multi = new CheckBox(MainActivity.this);
                multi.setText("Мультизаказ — добавить следующего клиента");
                multi.setTextSize(15);
                row.addView(multi, matchWrap());

                addressRows.addView(row, matchWrap());
                addressFields.add(address);
                multiChecks.add(multi);

                multi.setOnCheckedChangeListener((buttonView, checked) -> {
                    if (buttonView.isPressed()) {
                        if (checked) {
                            // После галочки появляется новая строка адреса + новая галочка.
                            if (addressFields.size() == index + 1) {
                                run();
                            }
                        } else {
                            // Если галочку сняли, убираем все последующие адреса цепочки.
                            while (addressFields.size() > index + 1) {
                                int last = addressFields.size() - 1;
                                addressRows.removeViewAt(last);
                                addressFields.remove(last);
                                multiChecks.remove(last);
                            }
                        }
                    }
                });
            }
        };
        addAddressRow.run();

        TextView multiHint = text(
                "☑️ Поставь галочку после адреса, если это мультизаказ. " +
                "Появится следующий адрес. Можно добавить сколько угодно клиентов.",
                12, false);
        multiHint.setPadding(dp(4), 0, 0, dp(6));
        box.addView(multiHint, matchWrap());

        TextView tariffInfo = text(
                "🏪 Забор: " + money(pickupFee) + " ₽ (только первый заказ)\n" +
                "👤 Выдача: " + money(deliveryFee) + " ₽ за каждого клиента\n" +
                "🚗 " + money(pricePerKm) + " ₽ за 1 км\n" +
                "⭐ Рейтинг " + ratingText(rating) + " → +" + money(ratingBonus(rating)) + " ₽ (только первый заказ)",
                14, false);
        tariffInfo.setPadding(0, dp(8), 0, dp(8));
        box.addView(tariffInfo, matchWrap());

        TextView status = text("Нажми «Рассчитать» — приложение найдёт адреса и построит цепочку маршрутов.", 13, false);
        status.setPadding(0, dp(8), 0, dp(8));
        box.addView(status, matchWrap());

        final android.app.AlertDialog dialog = new android.app.AlertDialog.Builder(this)
                .setTitle("➕ Добавить заказ")
                .setView(box)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Рассчитать", null)
                .create();

        dialog.setOnShowListener(ignored -> dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            if (chosen[0] == null) {
                toast("🏪 Выбери магазин");
                return;
            }

            List<String> addresses = new ArrayList<>();
            for (EditText field : addressFields) {
                String addr = field.getText().toString().trim();
                if (addr.isEmpty()) {
                    toast("📍 Введи адрес клиента " + (addresses.size() + 1));
                    return;
                }
                addresses.add(addr);
            }

            // Галочка должна быть установлена у каждого адреса, кроме последнего.
            for (int i = 0; i < multiChecks.size() - 1; i++) {
                if (!multiChecks.get(i).isChecked()) {
                    toast("☑️ Для продолжения мультизаказа поставь галочку после адреса " + (i + 1));
                    return;
                }
            }

            String key = getOrsKey();
            if (key.isEmpty()) {
                status.setText("❌ В APK не встроен API-ключ. Пересобери приложение с секретом ORS_API_KEY в GitHub.");
                return;
            }

            final int count = addresses.size();
            final List<String> addressList = new ArrayList<>(addresses);
            dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setEnabled(false);
            status.setText("🔄 Ищу адреса и рассчитываю цепочку 1/" + count + "…");

            executor.execute(() -> {
                try {
                    List<Point> destinations = new ArrayList<>();
                    for (int i = 0; i < addressList.size(); i++) {
                        final int progress = i + 1;
                        List<GeoCandidate> candidates = geocodeCandidates(addressList.get(i), key);
                        Point dest = confirmCandidateBlocking(addressList.get(i), candidates);
                        if (dest == null) throw new Exception("Адрес клиента " + progress + " не найден");
                        destinations.add(dest);
                        final String progressText = "🔄 Адреса найдены: " + progress + "/" + count;
                        runOnUiThread(() -> status.setText(progressText));
                    }

                    Point start = new Point(chosen[0].lat, chosen[0].lon);
                    List<Order> newOrders = new ArrayList<>();
                    double chainTotal = 0;
                    double chainKm = 0;

                    for (int i = 0; i < destinations.size(); i++) {
                        Point dest = destinations.get(i);
                        Route r = route(start.lat, start.lon, dest.lat, dest.lon, key);
                        boolean first = i == 0;
                        double rb = first ? ratingBonus(rating) : 0;
                        double pickup = first ? pickupFee : 0;
                        double total = pickup + deliveryFee + r.km * pricePerKm + rb;

                        newOrders.add(new Order(
                                total, r.km, r.minutes, System.currentTimeMillis() + i,
                                chosen[0].name, addressList.get(i), dest.lat, dest.lon,
                                rating, rb, count > 1, first
                        ));

                        chainTotal += total;
                        chainKm += r.km;
                        start = dest;
                        final int progress = i + 1;
                        final String progressText = "🔄 Маршрут " + progress + "/" + count + " рассчитан…";
                        runOnUiThread(() -> status.setText(progressText));
                    }

                    final double finalChainTotal = chainTotal;
                    final double finalChainKm = chainKm;
                    runOnUiThread(() -> {
                        orders.addAll(newOrders);
                        saveOrders();
                        refreshUi();
                        dialog.dismiss();
                        toast("✅ Добавлено клиентов: " + count + " • " + money(finalChainTotal) + " ₽ • " + km(finalChainKm) + " км");
                    });
                } catch (Exception e) {
                    runOnUiThread(() -> {
                        dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                        status.setText("❌ Ошибка: " + safeMessage(e));
                    });
                }
            });
        }));

        dialog.show();
    }

    private void showEditOrderDialog(final Order order) {
        final EditText address = field("📍 Адрес клиента", false);
        address.setText(order.address);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), 0, dp(20), 0);
        box.addView(text("🏪 " + order.storeName, 16, true), matchWrap());
        box.addView(address, matchWrap());

        TextView info = text(
                order.multiFirst
                        ? "🔗 Это первый заказ мультизаказа. Рейтинг и забор сохранятся."
                        : "🔗 Это продолжение мультизаказа. Забор и доплата за рейтинг не начисляются.",
                13, false);
        info.setPadding(0, dp(6), 0, dp(6));
        box.addView(info, matchWrap());

        TextView status = text("После сохранения адрес будет заново найден и маршрут пересчитан.", 13, false);
        box.addView(status, matchWrap());

        final android.app.AlertDialog dialog = new android.app.AlertDialog.Builder(this)
                .setTitle("✏️ Изменить заказ")
                .setView(box)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("💾 Сохранить", null)
                .create();

        dialog.setOnShowListener(ignored -> dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String newAddress = address.getText().toString().trim();
            if (newAddress.isEmpty()) {
                toast("📍 Введи адрес клиента");
                return;
            }

            String key = getOrsKey();
            if (key.isEmpty()) {
                status.setText("❌ В APK не встроен API-ключ.");
                return;
            }

            final int idx = orders.indexOf(order);
            if (idx < 0) {
                dialog.dismiss();
                return;
            }

            dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setEnabled(false);
            status.setText("🔄 Ищу новый адрес и пересчитываю маршрут…");

            executor.execute(() -> {
                try {
                    List<GeoCandidate> candidates = geocodeCandidates(newAddress, key);
                    Point dest = confirmCandidateBlocking(newAddress, candidates);
                    if (dest == null) throw new Exception("Адрес не найден");

                    // Recalculate the edited leg. For a multi-order, the start is
                    // the store for the first leg, otherwise the previous client.
                    Point start;
                    if (idx > 0 && isSameMultiChain(orders.get(idx - 1), order)) {
                        Order prev = orders.get(idx - 1);
                        start = new Point(prev.lat, prev.lon);
                    } else {
                        Store store = findStore(order.storeName);
                        if (store == null) throw new Exception("Магазин не найден");
                        start = new Point(store.lat, store.lon);
                    }

                    Route r = route(start.lat, start.lon, dest.lat, dest.lon, key);
                    final double newKm = r.km;
                    final int newMinutes = r.minutes;
                    final double newTotal = (order.multiFirst ? pickupFee : 0)
                            + deliveryFee + newKm * pricePerKm
                            + (order.multiFirst ? ratingBonus(order.rating) : 0);

                    runOnUiThread(() -> {
                        Order replacement = new Order(
                                newTotal, newKm, newMinutes, order.timestamp,
                                order.storeName, newAddress, dest.lat, dest.lon,
                                order.rating, order.multiFirst ? ratingBonus(order.rating) : 0,
                                order.isMulti, order.multiFirst
                        );
                        orders.set(idx, replacement);

                        // If the edited order is part of a multi-chain, the next leg
                        // starts from the edited client's new coordinates. Recalculate
                        // following legs automatically so the chain remains correct.
                        recalcFollowingMultiOrders(idx, key, dialog, status);
                    });
                } catch (Exception e) {
                    runOnUiThread(() -> {
                        dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                        status.setText("❌ Ошибка: " + safeMessage(e));
                    });
                }
            });
        }));

        dialog.show();
    }

    private boolean isSameMultiChain(Order a, Order b) {
        if (a == null || b == null || !a.isMulti || !b.isMulti) return false;
        if (!a.storeName.equals(b.storeName)) return false;
        return Math.abs(a.timestamp - b.timestamp) <= 1000;
    }

    private Store findStore(String name) {
        for (Store s : STORES) if (s.name.equals(name)) return s;
        return null;
    }

    private void recalcFollowingMultiOrders(int idx, String key,
                                            android.app.AlertDialog dialog, TextView status) {
        // Work on the already-replaced order and walk forward through its chain.
        if (idx + 1 >= orders.size() || !isSameMultiChain(orders.get(idx), orders.get(idx + 1))) {
            saveOrders();
            refreshUi();
            dialog.dismiss();
            toast("✅ Адрес изменён и маршрут пересчитан");
            return;
        }

        executor.execute(() -> {
            try {
                Point start = new Point(orders.get(idx).lat, orders.get(idx).lon);
                int i = idx + 1;
                while (i < orders.size() && isSameMultiChain(orders.get(i - 1), orders.get(i))) {
                    final int current = i;
                    Order old = orders.get(i);
                    Route r = route(start.lat, start.lon, old.lat, old.lon, key);
                    double total = deliveryFee + r.km * pricePerKm; // no pickup/rating for continuation
                    orders.set(i, new Order(
                            total, r.km, r.minutes, old.timestamp, old.storeName, old.address,
                            old.lat, old.lon, old.rating, 0, true, false
                    ));
                    start = new Point(old.lat, old.lon);
                    i++;
                    final int progress = i - idx - 1;
                    runOnUiThread(() -> status.setText("🔄 Пересчитываю следующий участок: " + progress + "…"));
                }

                runOnUiThread(() -> {
                    saveOrders();
                    refreshUi();
                    dialog.dismiss();
                    toast("✅ Адрес изменён и цепочка пересчитана");
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                    status.setText("❌ Ошибка пересчёта: " + safeMessage(e));
                });
            }
        });
    }

    private boolean isContinuationOfMulti(String storeName) {
        if (orders.isEmpty()) return false;
        Order last = orders.get(orders.size() - 1);
        return last.isMulti && last.storeName.equals(storeName);
    }

    private void confirmClear() {
        if (orders.isEmpty()) {
            toast("📭 Уже всё очищено");
            return;
        }
        new android.app.AlertDialog.Builder(this)
                .setTitle("🧹 Очистить статистику?")
                .setMessage("Будут удалены все добавленные заказы, километры и заработок. Настройки тарифа сохранятся.")
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Очистить", (d, w) -> {
                    orders.clear();
                    saveOrders();
                    refreshUi();
                    toast("✅ Статистика очищена");
                })
                .show();
    }

    private String getOrsKey() {
        return BuildConfig.ORS_API_KEY == null ? "" : BuildConfig.ORS_API_KEY.trim();
    }

    private double ratingBonus(double r) {
        if (r >= 5.0) return rating5;
        if (r >= 4.75) return rating475;
        if (r >= 4.50) return rating450;
        if (r >= 4.25) return rating425;
        return 0;
    }

    private void showSettingsDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), 0, dp(20), 0);

        TextView cityTitle = text("🏙️ Город по умолчанию", 18, true);
        cityTitle.setPadding(0, dp(4), 0, dp(6));
        box.addView(cityTitle, matchWrap());

        EditText cityField = field("Например: Егорьевск", false);
        cityField.setText(city);
        box.addView(cityField, matchWrap());

        TextView cityNote = text("При вводе адреса город автоматически добавляется к запросу. Например: «1 микрорайон, д.39» → «Егорьевск, 1 микрорайон, д.39». Если в адресе уже указан город, он не дублируется. В результатах показываются только адреса из города, указанного здесь.", 12, false);
        cityNote.setPadding(0, dp(4), 0, dp(10));
        box.addView(cityNote, matchWrap());

        TextView tariffTitle = text("💰 Тариф", 18, true);
        tariffTitle.setPadding(0, dp(4), 0, dp(6));
        box.addView(tariffTitle, matchWrap());

        EditText pickup = field("Забор заказа из магазина, ₽", true);
        pickup.setText(money(pickupFee));
        box.addView(pickup, matchWrap());

        EditText delivery = field("Выдача заказа клиенту, ₽", true);
        delivery.setText(money(deliveryFee));
        box.addView(delivery, matchWrap());

        EditText perKm = field("Цена за 1 км, ₽", true);
        perKm.setText(money(pricePerKm));
        box.addView(perKm, matchWrap());

        EditText currentRating = field("Текущий рейтинг (0–5)", true);
        currentRating.setText(ratingText(rating));
        box.addView(currentRating, matchWrap());

        TextView ratingTitle = text("⭐ Доплата за рейтинг", 18, true);
        ratingTitle.setPadding(0, dp(10), 0, dp(6));
        box.addView(ratingTitle, matchWrap());

        EditText r5 = field("⭐ 5.0 → ₽", true); r5.setText(money(rating5)); box.addView(r5, matchWrap());
        EditText r475 = field("⭐ 4.75–4.99 → ₽", true); r475.setText(money(rating475)); box.addView(r475, matchWrap());
        EditText r450 = field("⭐ 4.50–4.74 → ₽", true); r450.setText(money(rating450)); box.addView(r450, matchWrap());
        EditText r425 = field("⭐ 4.25–4.49 → ₽", true); r425.setText(money(rating425)); box.addView(r425, matchWrap());

        TextView below = text("⭐ Ниже 4.25 → 0 ₽", 14, false);
        below.setPadding(0, dp(4), 0, dp(10));
        box.addView(below, matchWrap());

        TextView routeTitle = text("🧭 Маршрутизация", 18, true);
        routeTitle.setPadding(0, dp(4), 0, dp(6));
        box.addView(routeTitle, matchWrap());

        TextView apiStatus = text(
                getOrsKey().isEmpty()
                        ? "🔑 API-ключ не встроен в эту сборку"
                        : "🔐 API-ключ встроен в приложение и берётся из GitHub Secret",
                13, false);
        apiStatus.setPadding(0, dp(8), 0, dp(4));
        box.addView(apiStatus, matchWrap());

        TextView note = text("🚗 Расстояние считается по автомобильным дорогам (профиль driving-car), а не по прямой. Точность — 0,1 км. Время — без учёта пробок. Ключ вручную вводить не нужно.", 12, false);
        note.setPadding(0, dp(6), 0, dp(4));
        box.addView(note, matchWrap());

        new android.app.AlertDialog.Builder(this)
                .setTitle("⚙️ Настройки")
                .setView(box)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("💾 Сохранить", (d, w) -> {
                    String newCity = cityField.getText().toString().trim();
                    double newPickup = parseNonNegative(pickup.getText().toString(), -1);
                    double newDelivery = parseNonNegative(delivery.getText().toString(), -1);
                    double newPerKm = parseNonNegative(perKm.getText().toString(), -1);
                    double newRating = parseNumber(currentRating.getText().toString(), -1);
                    double new5 = parseNonNegative(r5.getText().toString(), -1);
                    double new475 = parseNonNegative(r475.getText().toString(), -1);
                    double new450 = parseNonNegative(r450.getText().toString(), -1);
                    double new425 = parseNonNegative(r425.getText().toString(), -1);

                    if (newCity.isEmpty() || newPickup < 0 || newDelivery < 0 || newPerKm < 0 || newRating < 0 || newRating > 5 ||
                            new5 < 0 || new475 < 0 || new450 < 0 || new425 < 0) {
                        toast("❌ Проверь значения тарифа и рейтинга");
                        return;
                    }

                    city = newCity;
                    pickupFee = newPickup;
                    deliveryFee = newDelivery;
                    pricePerKm = newPerKm;
                    rating = newRating;
                    rating5 = new5;
                    rating475 = new475;
                    rating450 = new450;
                    rating425 = new425;

                    prefs.edit()
                            .putString(CITY, city)
                            .putString(PICKUP_FEE, Double.toString(pickupFee))
                            .putString(DELIVERY_FEE, Double.toString(deliveryFee))
                            .putString(PRICE_PER_KM, Double.toString(pricePerKm))
                            .putString(RATING, Double.toString(rating))
                            .putString(RATING_5, Double.toString(rating5))
                            .putString(RATING_475, Double.toString(rating475))
                            .putString(RATING_450, Double.toString(rating450))
                            .putString(RATING_425, Double.toString(rating425))
                            .apply();

                    refreshUi();
                    toast("✅ Настройки сохранены");
                })
                .show();
    }

    private List<GeoCandidate> geocodeCandidates(String address, String key) throws Exception {
        String original = address == null ? "" : address.trim();
        if (original.isEmpty()) return Collections.emptyList();

        String configuredCity = city == null ? "" : city.trim();
        String query = addConfiguredCity(original, configuredCity);

        AddressParts parts = parseAddressParts(original, configuredCity);
        String inputNorm = normalizeAddress(original);
        String inputHouse = parts.house.isEmpty() ? extractHouseNumber(inputNorm) : normalizeHouse(parts.house);
        String inputLocality = normalizeAddress(parts.locality);
        String inputStreet = normalizeAddress(parts.street);
        String inputStreetBase = normalizeStreetName(parts.street);
        String inputMicrodistrict = normalizeAddress(parts.microdistrict);
        String inputSntName = normalizeSntName(parts.sntName);

        List<GeoCandidate> all = new ArrayList<>();

        // 1. Exact house search. Restrict Pelias to address layer whenever a
        // house number is present. This prevents postal codes/cities from
        // being accepted as the destination.
        if (!inputHouse.isEmpty()) {
            // Для микрорайонов используем отдельное поле neighbourhood. Это
            // существенно точнее, чем отправлять «1 микрорайон 39» как улицу.
            if (!inputMicrodistrict.isEmpty()) {
                String structuredMicro = ORS_GEOCODE_BASE + "/search/structured?"
                        + "address=" + enc(inputHouse)
                        + "&neighbourhood=" + enc(parts.microdistrict)
                        + "&locality=" + enc(parts.locality.isEmpty() ? configuredCity : parts.locality)
                        + "&region=" + enc("Московская область")
                        + "&country=" + enc("RUS")
                        + "&size=50&lang=ru&boundary.country=RUS&layers=address";
                try { all.addAll(parseGeoCandidates(httpGet(structuredMicro, key))); } catch (Exception ignored) {}
            }

            String structuredUrl = ORS_GEOCODE_BASE + "/search/structured?"
                    + "address=" + enc(parts.addressForStructured())
                    + "&locality=" + enc(parts.locality.isEmpty() ? configuredCity : parts.locality)
                    + "&region=" + enc("Московская область")
                    + "&country=" + enc("RUS")
                    + "&size=50&lang=ru&boundary.country=RUS&layers=address";
            try { all.addAll(parseGeoCandidates(httpGet(structuredUrl, key))); } catch (Exception ignored) {}

            // Несколько вариантов написания повышают шанс найти дом в OSM:
            // «1-й микрорайон, 39», «1 микрорайон, д.39» и «39, 1 микрорайон».
            // Для шоссе/трасс геокодер может индексировать название
            // немного иначе: «Коломенское шоссе», «Коломенское»,
            // «Касимовское шоссе». Поэтому отправляем несколько точных
            // вариантов, сохраняя обязательный номер дома и город.
            List<String> exactQueryList = new ArrayList<>();
            // Садовые некоммерческие товарищества (СНТ): геокодеры могут
            // индексировать их как territory/neighbourhood/locality и по-разному
            // записывать приставку «СНТ». Поэтому ищем и полное, и короткое имя
            // товарищества, всегда сохраняя номер дома/участка.
            if (!inputSntName.isEmpty()) {
                String snt = parts.sntName.trim();
                exactQueryList.add(configuredCity + ", СНТ " + snt + ", " + inputHouse + ", Россия");
                exactQueryList.add(configuredCity + ", " + snt + ", " + inputHouse + ", Россия");
                exactQueryList.add("СНТ " + snt + ", " + inputHouse + ", " + configuredCity + ", Россия");
                exactQueryList.add(configuredCity + ", территория СНТ " + snt + ", " + inputHouse + ", Россия");
                exactQueryList.add(configuredCity + ", территория " + snt + ", " + inputHouse + ", Россия");
                exactQueryList.add(configuredCity + ", СНТ " + snt + " территория, " + inputHouse + ", Россия");
                exactQueryList.add(configuredCity + ", " + snt + " территория, " + inputHouse + ", Россия");
                exactQueryList.add(configuredCity + ", СНТ " + snt + ", дом " + inputHouse + ", Россия");
                exactQueryList.add(configuredCity + ", СНТ " + snt + ", участок " + inputHouse + ", Россия");
            }
            if (!inputMicrodistrict.isEmpty()) {
                String micro = parts.microdistrict.trim();
                exactQueryList.add(configuredCity + ", микрорайон " + micro + ", " + inputHouse + ", Россия");
                exactQueryList.add(configuredCity + ", мкр " + micro + ", " + inputHouse + ", Россия");
                exactQueryList.add(configuredCity + ", " + micro + ", " + inputHouse + ", Россия");
                exactQueryList.add(micro + ", " + inputHouse + ", " + configuredCity + ", Россия");
            }
            exactQueryList.add(query);
            exactQueryList.add(configuredCity + ", " + parts.addressForStructured() + ", Россия");
            if (!parts.street.isEmpty()) {
                // Universal street-type variants: street/avenue/highway/lane/etc.
                // Keep the house number in every query.
                String streetBase = normalizeStreetName(parts.street);
                String[] streetForms = streetForms(parts.street);
                for (String form : streetForms) {
                    if (form == null || form.trim().isEmpty()) continue;
                    exactQueryList.add(configuredCity + ", " + form + ", " + inputHouse + ", Россия");
                    exactQueryList.add(form + ", " + inputHouse + ", " + configuredCity + ", Россия");
                }
                if (!streetBase.isEmpty()) {
                    exactQueryList.add(configuredCity + ", " + streetBase + ", " + inputHouse + ", Россия");
                    exactQueryList.add(configuredCity + ", " + inputHouse + ", " + streetBase + ", Россия");
                }
            }
            exactQueryList.add(configuredCity + ", " + parts.microdistrict + ", " + inputHouse + ", Россия");
            exactQueryList.add(parts.microdistrict + ", " + inputHouse + ", " + configuredCity + ", Россия");
            exactQueryList.add(inputHouse + ", " + parts.microdistrict + ", " + configuredCity + ", Россия");
            all.addAll(parallelOrsSearch(exactQueryList, key));

            if (!parts.locality.isEmpty()) {
                String explicit = configuredCity + ", " + parts.locality + ", " +
                        (parts.street.isEmpty() ? "" : parts.street + ", ") + inputHouse + ", Россия";
                String u = ORS_GEOCODE_BASE + "/search?text=" + enc(explicit)
                        + "&size=50&lang=ru&boundary.country=RUS&layers=address";
                try { all.addAll(parseGeoCandidates(httpGet(u, key))); } catch (Exception ignored) {}
            }
        }

        // 2. Normal search as a fallback, but only address/venue/locality
        // results are considered and non-house results are rejected later
        // when a house number was entered.
        String normal = ORS_GEOCODE_BASE + "/search?text=" + enc(query)
                + "&size=50&lang=ru&boundary.country=RUS&layers=address,venue,locality";
        try { all.addAll(parseGeoCandidates(httpGet(normal, key))); } catch (Exception ignored) {}

        // ORS/Pelias does not index every Russian house, especially addresses
        // written as a microdistrict or a territory of an СНТ.  If ORS did not
        // return a concrete house in the configured city, use OSM Nominatim as
        // a fallback geocoder.  Routing itself still remains ORS/driving-car.
        if (!hasExactAddressContext(all, inputHouse, parts, configuredCity)) {
            all.addAll(parallelFallbackSearch(nominatimQueries(original, query, parts, configuredCity), photonQueries(original, query, parts, configuredCity)));
        }

        List<ScoredCandidate> scored = new ArrayList<>();
        java.util.HashSet<String> seen = new java.util.HashSet<>();

        for (GeoCandidate candidate : all) {
            String candidateNorm = normalizeAddress(candidate.label);
            if (candidateNorm.isEmpty()) continue;

            // City restriction is based on Pelias address components first,
            // and only then on the display label.
            if (!belongsToConfiguredCity(candidate, configuredCity)) continue;

            String id = String.format(java.util.Locale.US, "%.6f,%.6f", candidate.lat, candidate.lon);
            if (!seen.add(id)) continue;

            String candidateHouse = normalizeHouse(candidate.house);
            // Для СНТ нельзя извлекать номер дома из display_name: в названии
            // самого товарищества часто есть цифра (например, «Комсомолец-1»).
            // Иначе эта цифра ошибочно принимается за номер дома.
            if (candidateHouse.isEmpty() && inputSntName.isEmpty()) {
                candidateHouse = extractHouseNumber(candidateNorm);
            }

            // If a concrete house was entered, only a concrete matching house
            // is acceptable. A city, street or postal-code point is never a
            // valid replacement for "дом 39".
            if (!inputHouse.isEmpty()) {
                boolean sntTerritoryFallback = !inputSntName.isEmpty() && candidate.isSntLike(inputSntName);
                if (candidateHouse.isEmpty()) {
                    if (!sntTerritoryFallback) continue;
                } else if (!inputHouse.equals(candidateHouse)) {
                    continue;
                }
                if (!candidate.isHouse() && !sntTerritoryFallback) continue;
            }

            if (!inputLocality.isEmpty()) {
                String cl = normalizeAddress(candidate.locality);
                String cc = normalizeAddress(candidate.city);
                if (!candidateNorm.contains(inputLocality) &&
                        !cl.contains(inputLocality) &&
                        !cc.contains(inputLocality)) continue;
            }

            if (!inputMicrodistrict.isEmpty()) {
                String cn = normalizeAddress(candidate.neighbourhood);
                if (!microdistrictEquivalent(inputMicrodistrict, cn) &&
                        !microdistrictEquivalent(inputMicrodistrict, candidateNorm)) continue;
            }

            if (!inputSntName.isEmpty()) {
                String sntHaystack = normalizeAddress(candidate.label + " " + candidate.neighbourhood + " " +
                        candidate.locality + " " + candidate.street);
                if (!sntEquivalent(inputSntName, sntHaystack)) continue;
            }

            if (!inputStreet.isEmpty() && inputSntName.isEmpty()) {
                String cs = normalizeAddress(candidate.street);
                String candidateStreetBase = normalizeStreetName(candidate.street);
                boolean streetMatch = candidateNorm.contains(inputStreet) ||
                        cs.contains(inputStreet) ||
                        (!inputStreetBase.isEmpty() &&
                                (candidateStreetBase.equals(inputStreetBase) ||
                                 candidateStreetBase.contains(inputStreetBase) ||
                                 inputStreetBase.contains(candidateStreetBase)));
                if (!streetMatch) {
                    if (!inputStreet.contains("микрорайон")) continue;
                }
            }

            int score = 100;
            boolean sntTerritoryFallback = !inputSntName.isEmpty() && candidate.isSntLike(inputSntName);
            if (!inputHouse.isEmpty()) score += candidateHouse.isEmpty() ? 500 : 2000;
            if (!candidate.house.isEmpty()) score += 500;
            if (!candidate.isHouse()) score += sntTerritoryFallback ? -250 : -1500;

            if (!inputLocality.isEmpty()) {
                String cl = normalizeAddress(candidate.locality);
                String cc = normalizeAddress(candidate.city);
                if (cl.contains(inputLocality) || cc.contains(inputLocality)) score += 700;
                else score -= 300;
            }

            if (!inputMicrodistrict.isEmpty()) {
                String cn = normalizeAddress(candidate.neighbourhood);
                if (microdistrictEquivalent(inputMicrodistrict, cn) ||
                        microdistrictEquivalent(inputMicrodistrict, candidateNorm)) score += 900;
            }

            if (!inputSntName.isEmpty()) {
                String sntHaystack = normalizeAddress(candidate.label + " " + candidate.neighbourhood + " " +
                        candidate.locality + " " + candidate.street);
                if (sntEquivalent(inputSntName, sntHaystack)) score += 1100;
            }

            if (!inputStreet.isEmpty() && inputSntName.isEmpty()) {
                String cs = normalizeAddress(candidate.street);
                String candidateStreetBase = normalizeStreetName(candidate.street);
                if (cs.contains(inputStreet) || candidateNorm.contains(inputStreet) ||
                        (!inputStreetBase.isEmpty() && candidateStreetBase.equals(inputStreetBase))) score += 600;
            }

            if (candidate.confidence > 0) score += (int) Math.round(candidate.confidence * 500);
            if ("point".equalsIgnoreCase(candidate.accuracy)) score += 150;
            if ("exact".equalsIgnoreCase(candidate.matchType)) score += 200;
            if (candidateNorm.contains(inputNorm)) score += 400;
            if ("address".equalsIgnoreCase(candidate.layer)) score += 300;

            scored.add(new ScoredCandidate(candidate, score));
        }

        Collections.sort(scored, (a, b) -> Integer.compare(b.score, a.score));

        List<GeoCandidate> result = new ArrayList<>();
        for (ScoredCandidate sc : scored) {
            result.add(sc.candidate);
            if (result.size() >= 10) break;
        }
        return result;
    }

    private List<GeoCandidate> parallelOrsSearch(List<String> queries, String key) {
        List<GeoCandidate> out = new ArrayList<>();
        if (queries == null || queries.isEmpty()) return out;
        java.util.LinkedHashSet<String> unique = new java.util.LinkedHashSet<>();
        for (String q : queries) if (q != null && !q.trim().isEmpty()) unique.add(q.trim());
        List<java.util.concurrent.Future<List<GeoCandidate>>> futures = new ArrayList<>();
        for (String q : unique) {
            futures.add(geocodeExecutor.submit(() -> {
                try {
                    String exact = ORS_GEOCODE_BASE + "/search?text=" + enc(q)
                            + "&size=20&lang=ru&boundary.country=RUS&layers=address,venue,locality";
                    return parseGeoCandidates(httpGet(exact, key));
                } catch (Exception ignored) { return Collections.emptyList(); }
            }));
        }
        for (java.util.concurrent.Future<List<GeoCandidate>> f : futures) {
            try { out.addAll(f.get(6500, java.util.concurrent.TimeUnit.MILLISECONDS)); }
            catch (Exception ignored) { f.cancel(true); }
        }
        return out;
    }

    private List<GeoCandidate> parallelFallbackSearch(List<String> nominatim, List<String> photon) {
        List<GeoCandidate> out = new ArrayList<>();
        List<java.util.concurrent.Future<List<GeoCandidate>>> futures = new ArrayList<>();
        java.util.LinkedHashSet<String> nqs = new java.util.LinkedHashSet<>();
        if (nominatim != null) for (String q : nominatim) if (q != null && !q.trim().isEmpty()) nqs.add(q.trim());
        // Keep public fallbacks bounded: at most 2 Nominatim + 2 Photon requests.
        int n = 0;
        for (String q : nqs) {
            if (n++ >= 2) break;
            futures.add(geocodeExecutor.submit(() -> {
                try { return parseNominatimCandidates(httpGetNominatim(q)); } catch (Exception ignored) { return Collections.emptyList(); }
            }));
        }
        java.util.LinkedHashSet<String> pqs = new java.util.LinkedHashSet<>();
        if (photon != null) for (String q : photon) if (q != null && !q.trim().isEmpty()) pqs.add(q.trim());
        int p = 0;
        for (String q : pqs) {
            if (p++ >= 2) break;
            futures.add(geocodeExecutor.submit(() -> {
                try { return parsePhotonCandidates(httpGetPhoton(q)); } catch (Exception ignored) { return Collections.emptyList(); }
            }));
        }
        for (java.util.concurrent.Future<List<GeoCandidate>> f : futures) {
            try { out.addAll(f.get(8000, java.util.concurrent.TimeUnit.MILLISECONDS)); }
            catch (Exception ignored) { f.cancel(true); }
        }
        return out;
    }

    private boolean belongsToConfiguredCity(GeoCandidate candidate, String configuredCity) {
        if (configuredCity == null || configuredCity.trim().isEmpty()) return true;

        String wanted = normalizeAddress(configuredCity);
        if (wanted.isEmpty()) return true;

        // Prefer structured fields from Pelias. This avoids accepting a result
        // merely because the word "Егорьевск" happens to appear in a postal
        // address.
        String[] structured = {
                normalizeAddress(candidate.city),
                normalizeAddress(candidate.locality),
                normalizeAddress(candidate.label)
        };

        for (String value : structured) {
            if (!value.isEmpty() && value.matches(".*(?:^|\\s)" +
                    java.util.regex.Pattern.quote(wanted) + "(?:\\s|$).*")) {
                return true;
            }
        }
        if (wanted.equals("егорьевск")) {
            String hay = normalizeAddress(candidate.label + " " + candidate.locality + " " + candidate.region);
            if (hay.contains("егорьевский муниципальный округ") ||
                    hay.contains("городской округ егорьевск") ||
                    hay.contains("муниципальный округ егорьевск")) {
                return true;
            }
        }
        return false;
    }

    private String normalizeHouse(String value) {
        String s = value == null ? "" : value.toLowerCase(java.util.Locale.ROOT)
                .replace('ё', 'е').trim();
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("(\\d+[а-я]?(?:[-/]\\d+[а-я]?)?(?:к\\d+[а-я]?)?)")
                .matcher(s);
        return m.find() ? m.group(1) : "";
    }

    private String normalizeStreetName(String value) {
        String s = value == null ? "" : value.toLowerCase(java.util.Locale.ROOT)
                .replace('ё', 'е').trim();
        s = s.replaceAll("[.,]", " ").replaceAll("\\s+", " ").trim();
        s = s.replaceAll("(?i)^(?:улица|ул|проспект|просп|пр-т|шоссе|ш|переулок|пер|проезд|пр|площадь|пл|набережная|наб|бульвар|бул|аллея|ал|тракт|тупик|туп|линия|квартал|территория|тер)\\s+", "");
        s = s.replaceAll("(?i)\\s+(?:улица|ул|проспект|просп|пр-т|шоссе|ш|переулок|пер|проезд|пр|площадь|пл|набережная|наб|бульвар|бул|аллея|ал|тракт|тупик|туп|линия|квартал|территория|тер)$", "");
        return s.replaceAll("\\s+", " ").trim();
    }

    private String[] streetForms(String street) {
        String s = street == null ? "" : street.trim();
        String base = normalizeStreetName(s);
        String low = s.toLowerCase(java.util.Locale.ROOT).replace('ё','е');
        java.util.LinkedHashSet<String> forms = new java.util.LinkedHashSet<>();
        forms.add(s); if (!base.isEmpty()) forms.add(base);
        if (low.matches(".*\\b(?:улица|ул)\\.?\\b.*")) { forms.add("улица " + base); forms.add("ул. " + base); }
        if (low.matches(".*\\b(?:проспект|просп|пр-т)\\.?\\b.*")) { forms.add("проспект " + base); forms.add("пр-т " + base); forms.add("просп. " + base); }
        if (low.matches(".*\\b(?:шоссе|ш)\\.?\\b.*")) { forms.add(base + " шоссе"); forms.add(base + " ш."); forms.add("шоссе " + base); }
        if (low.matches(".*\\b(?:переулок|пер)\\.?\\b.*")) { forms.add("переулок " + base); forms.add("пер. " + base); }
        if (low.matches(".*\\b(?:проезд|пр)\\.?\\b.*")) { forms.add("проезд " + base); forms.add("пр. " + base); }
        if (low.matches(".*\\b(?:набережная|наб)\\.?\\b.*")) { forms.add("набережная " + base); forms.add("наб. " + base); }
        if (low.matches(".*\\b(?:бульвар|бул)\\.?\\b.*")) { forms.add("бульвар " + base); forms.add("бул. " + base); }
        if (low.matches(".*\\b(?:площадь|пл)\\.?\\b.*")) { forms.add("площадь " + base); forms.add("пл. " + base); }
        return forms.toArray(new String[0]);
    }

    private String addConfiguredCity(String original, String configuredCity) {
        String q = original.trim();
        String lower = q.toLowerCase(java.util.Locale.ROOT).replace('ё', 'е');
        String cityLower = configuredCity.toLowerCase(java.util.Locale.ROOT).replace('ё', 'е');
        if (!cityLower.isEmpty() && !lower.contains(cityLower)) {
            q += ", " + configuredCity + ", Россия";
        }
        return q;
    }

    private String enc(String value) throws Exception {
        return URLEncoder.encode(value == null ? "" : value, StandardCharsets.UTF_8.name());
    }

    private boolean hasExactAddressContext(List<GeoCandidate> candidates, String inputHouse,
                                           AddressParts parts, String configuredCity) {
        if (candidates == null || candidates.isEmpty()) return false;
        if (inputHouse == null || inputHouse.trim().isEmpty()) return true;

        String wantedHouse = normalizeHouse(inputHouse);
        String wantedMicro = normalizeAddress(parts == null ? "" : parts.microdistrict);
        String wantedSnt = normalizeSntName(parts == null ? "" : parts.sntName);
        String wantedLocality = normalizeAddress(parts == null ? "" : parts.locality);
        String wantedStreet = normalizeAddress(parts == null ? "" : parts.street);
        String wantedStreetBase = normalizeStreetName(parts == null ? "" : parts.street);

        for (GeoCandidate c : candidates) {
            if (!belongsToConfiguredCity(c, configuredCity)) continue;
            String h = normalizeHouse(c.house);
            if (h.isEmpty()) h = normalizeHouse(extractHouseNumber(normalizeAddress(c.label)));
            if (!wantedHouse.equals(h) || !c.isHouse()) continue;

            // It is not enough to find the same house number somewhere in the
            // configured city. Example: "Заречье, 25Б" can coexist with other
            // 25Б results. The exact context must match too, otherwise a wrong
            // 25Б suppresses the Nominatim fallback and the final filter leaves
            // us with zero candidates.
            if (!wantedMicro.isEmpty()) {
                String cn = normalizeAddress(c.neighbourhood);
                if (!microdistrictEquivalent(wantedMicro, cn) &&
                        !microdistrictEquivalent(wantedMicro, c.label)) continue;
            }

            if (!wantedSnt.isEmpty()) {
                String hay = normalizeAddress(c.label + " " + c.neighbourhood + " " +
                        c.locality + " " + c.street);
                if (!sntEquivalent(wantedSnt, hay)) continue;
            }

            if (!wantedLocality.isEmpty()) {
                String cl = normalizeAddress(c.locality);
                String cc = normalizeAddress(c.city);
                String cn = normalizeAddress(c.label);
                if (!cl.contains(wantedLocality) && !cc.contains(wantedLocality) &&
                        !cn.contains(wantedLocality)) continue;
            }

            if (!wantedStreet.isEmpty() && wantedSnt.isEmpty()) {
                String cs = normalizeAddress(c.street);
                String cb = normalizeStreetName(c.street);
                boolean streetMatch = cnContains(c.label, wantedStreet) ||
                        cs.contains(wantedStreet) ||
                        (!wantedStreetBase.isEmpty() &&
                                (cb.equals(wantedStreetBase) || cb.contains(wantedStreetBase) ||
                                 wantedStreetBase.contains(cb)));
                if (!streetMatch && wantedMicro.isEmpty()) continue;
            }
            return true;
        }
        return false;
    }

    private boolean cnContains(String label, String wanted) {
        return normalizeAddress(label).contains(normalizeAddress(wanted));
    }

    private List<String> nominatimQueries(String original, String query, AddressParts parts, String configuredCity) {
        // Nominatim is a public fallback service, so deliberately make only
        // one request per failed address lookup. Prefer the most structured
        // form for microdistricts/SNT, otherwise use the user's full query.
        String cityName = configuredCity == null ? "" : configuredCity.trim();
        String house = parts.house == null ? "" : parts.house.trim();
        String best;

        if (!parts.sntName.isEmpty() && !house.isEmpty()) {
            best = cityName + ", СНТ " + parts.sntName.trim() + ", " + house + ", Россия";
        } else if (!parts.microdistrict.isEmpty() && !house.isEmpty()) {
            best = cityName + ", микрорайон " + parts.microdistrict.trim() + ", " + house + ", Россия";
        } else {
            best = query == null || query.trim().isEmpty() ? original : query;
        }

        java.util.LinkedHashSet<String> result = new java.util.LinkedHashSet<>();
        if (best != null && !best.trim().isEmpty()) result.add(best.trim());

        // A few bounded variants are important for Russian OSM records where
        // the same microdistrict/SNT is stored without the words "микрорайон"
        // or "СНТ". Never drop the house number.
        if (!house.isEmpty() && !parts.microdistrict.isEmpty()) {
            String m = parts.microdistrict.trim();
            result.add(cityName + ", " + m + ", " + house + ", Россия");
            result.add(cityName + ", микрорайон " + m + ", " + house + ", Россия");
            result.add(cityName + ", мкр " + m + ", " + house + ", Россия");
            result.add(cityName + ", " + m + " микрорайон, " + house + ", Россия");
            result.add(m + ", " + house + ", " + cityName + ", Россия");
        }
        if (!house.isEmpty() && !parts.sntName.isEmpty()) {
            String snt = parts.sntName.trim();
            result.add(cityName + ", " + snt + ", " + house + ", Россия");
            result.add(cityName + ", СНТ " + snt + ", " + house + ", Россия");
            result.add(cityName + ", территория СНТ " + snt + ", " + house + ", Россия");
            result.add(cityName + ", территория " + snt + ", " + house + ", Россия");
            result.add(cityName + ", СНТ " + snt + " территория, " + house + ", Россия");
            result.add("СНТ " + snt + ", " + house + ", Егорьевский муниципальный округ, Московская область, Россия");
            result.add(cityName + ", " + snt + " территория, " + house + ", Россия");
            result.add("СНТ " + snt + ", участок " + house + ", " + cityName + ", Россия");
        }
        if (!house.isEmpty() && !parts.street.isEmpty()) {
            result.add(cityName + ", " + parts.street.trim() + ", " + house + ", Россия");
        }
        return new ArrayList<>(result);
    }

    private String httpGetNominatim(String query) throws Exception {
        String url = NOMINATIM_BASE + "?format=jsonv2&addressdetails=1&limit=10&countrycodes=ru&accept-language=ru&q=" + enc(query);
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod("GET");
        c.setConnectTimeout(12000);
        c.setReadTimeout(15000);
        c.setRequestProperty("User-Agent", "CourierMoney/2.7 Android address search");
        c.setRequestProperty("Accept", "application/json");
        return read(c);
    }

    private List<String> photonQueries(String original, String query, AddressParts parts, String configuredCity) {
        String cityName = configuredCity == null ? "" : configuredCity.trim();
        String house = parts.house == null ? "" : parts.house.trim();
        java.util.LinkedHashSet<String> result = new java.util.LinkedHashSet<>();
        if (!parts.sntName.isEmpty() && !house.isEmpty()) {
            String snt = parts.sntName.trim();
            result.add(cityName + ", СНТ " + snt + ", " + house + ", Россия");
            result.add("СНТ " + snt + ", " + house + ", " + cityName + ", Россия");
            result.add(cityName + ", тер. СНТ " + snt + ", " + house + ", Россия");
            result.add(cityName + ", территория СНТ " + snt + ", " + house + ", Россия");
        } else if (!parts.microdistrict.isEmpty() && !house.isEmpty()) {
            String m = parts.microdistrict.trim();
            result.add(cityName + ", микрорайон " + m + ", " + house + ", Россия");
            result.add(cityName + ", мкр " + m + ", " + house + ", Россия");
            result.add(cityName + ", " + m + ", " + house + ", Россия");
            if (normalizeAddress(m).equals("лесной")) {
                result.add("Холмы, микрорайон Лесной, " + house + ", Егорьевский муниципальный округ, Россия");
                result.add("деревня Холмы, Лесной микрорайон, " + house + ", Егорьевск, Россия");
            }
        } else if (query != null && !query.trim().isEmpty()) {
            result.add(query);
        }
        return new ArrayList<>(result);
    }

    private String httpGetPhoton(String query) throws Exception {
        String url = PHOTON_BASE + "?lang=ru&limit=10&q=" + enc(query);
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod("GET");
        c.setConnectTimeout(12000);
        c.setReadTimeout(15000);
        c.setRequestProperty("User-Agent", "CourierMoney/2.7 Android address search");
        c.setRequestProperty("Accept", "application/json");
        return read(c);
    }

    private List<GeoCandidate> parsePhotonCandidates(String json) throws Exception {
        List<GeoCandidate> result = new ArrayList<>();
        JSONObject root = new JSONObject(json);
        JSONArray feats = root.optJSONArray("features");
        if (feats == null) return result;
        for (int i = 0; i < feats.length(); i++) {
            JSONObject f = feats.optJSONObject(i);
            if (f == null) continue;
            JSONObject props = f.optJSONObject("properties");
            JSONObject geometry = f.optJSONObject("geometry");
            if (props == null || geometry == null) continue;
            JSONArray c = geometry.optJSONArray("coordinates");
            if (c == null || c.length() < 2) continue;
            double lon = c.optDouble(0, Double.NaN);
            double lat = c.optDouble(1, Double.NaN);
            if (!Double.isFinite(lat) || !Double.isFinite(lon)) continue;
            String house = props.optString("housenumber", "").trim();
            String street = firstNonEmpty(props.optString("street", ""), props.optString("name", ""));
            String neighbourhood = firstNonEmpty(props.optString("district", ""), props.optString("suburb", ""));
            String locality = firstNonEmpty(props.optString("city", ""), props.optString("town", ""), props.optString("village", ""), props.optString("locality", ""), props.optString("county", ""));
            String region = firstNonEmpty(props.optString("state", ""));
            String label = props.optString("name", "").trim();
            if (!street.isEmpty() && !house.isEmpty()) label = street + ", " + house;
            if (label.isEmpty()) label = street;
            if (!locality.isEmpty()) { if (!label.isEmpty()) label += ", "; label += locality; }
            if (!region.isEmpty()) { if (!label.isEmpty()) label += ", "; label += region; }
            if (label.isEmpty()) continue;
            String layer = !house.isEmpty() ? "address" : props.optString("type", "");
            result.add(new GeoCandidate(label, house, street, neighbourhood, locality, locality, region, layer, props.optDouble("importance", 0), house.isEmpty() ? "" : "point", "", lat, lon));
        }
        return result;
    }

    private List<GeoCandidate> parseNominatimCandidates(String json) throws Exception {
        List<GeoCandidate> result = new ArrayList<>();
        JSONArray arr = new JSONArray(json);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            double lat;
            double lon;
            try {
                lat = Double.parseDouble(o.optString("lat", ""));
                lon = Double.parseDouble(o.optString("lon", ""));
            } catch (Exception e) {
                continue;
            }
            if (!Double.isFinite(lat) || !Double.isFinite(lon)) continue;

            JSONObject a = o.optJSONObject("address");
            if (a == null) a = new JSONObject();
            String house = a.optString("house_number", "").trim();
            String street = firstNonEmpty(a.optString("road", ""), a.optString("street", ""), a.optString("pedestrian", ""));
            String neighbourhood = firstNonEmpty(a.optString("neighbourhood", ""), a.optString("suburb", ""), a.optString("city_district", ""));
            String locality = firstNonEmpty(a.optString("city", ""), a.optString("town", ""), a.optString("village", ""), a.optString("municipality", ""));
            String region = firstNonEmpty(a.optString("state", ""), a.optString("region", ""));
            String label = o.optString("display_name", "").trim();
            if (label.isEmpty()) continue;

            String type = o.optString("type", "").trim();
            String osmType = o.optString("osm_type", "").trim();
            String layer = (!house.isEmpty() || "house".equalsIgnoreCase(type) || "building".equalsIgnoreCase(type)) ? "address" : type;
            double importance = o.optDouble("importance", 0);
            String accuracy = (!house.isEmpty() ? "point" : osmType);

            result.add(new GeoCandidate(label, house, street, neighbourhood, locality, locality, region,
                    layer, importance, accuracy, "", lat, lon));
        }
        return result;
    }

    private String firstNonEmpty(String... values) {
        for (String v : values) {
            if (v != null && !v.trim().isEmpty()) return v.trim();
        }
        return "";
    }

    private List<GeoCandidate> parseGeoCandidates(String json) throws Exception {
        List<GeoCandidate> result = new ArrayList<>();
        JSONObject root = new JSONObject(json);
        JSONArray feats = root.optJSONArray("features");
        if (feats == null) return result;

        for (int i = 0; i < feats.length(); i++) {
            JSONObject f = feats.optJSONObject(i);
            if (f == null) continue;
            JSONObject props = f.optJSONObject("properties");
            JSONObject geometry = f.optJSONObject("geometry");
            if (props == null || geometry == null) continue;

            JSONArray c = geometry.optJSONArray("coordinates");
            if (c == null || c.length() < 2) continue;

            String label = props.optString("label", "").trim();
            if (label.isEmpty()) continue;

            // Pelias returns the important address parts separately. Do not try
            // to reconstruct the house number only from the display label:
            // postal-code results such as "140300, Егорьевск" are not houses.
            String house = props.optString("housenumber", "").trim();
            String street = props.optString("street", "").trim();
            String neighbourhood = props.optString("neighbourhood", "").trim();
            String locality = props.optString("locality", "").trim();
            if (locality.isEmpty()) locality = props.optString("localadmin", "").trim();
            String candidateCity = props.optString("city", "").trim();
            if (candidateCity.isEmpty()) candidateCity = locality;
            String region = props.optString("region", "").trim();
            String layer = props.optString("layer", "").trim();
            double confidence = props.optDouble("confidence", 0);
            String accuracy = props.optString("accuracy", "").trim();
            String matchType = props.optString("match_type", "").trim();

            result.add(new GeoCandidate(
                    label, house, street, neighbourhood, locality, candidateCity, region, layer,
                    confidence, accuracy, matchType, c.getDouble(1), c.getDouble(0)
            ));
        }
        return result;
    }

    private String normalizeSntName(String value) {
        String s = normalizeAddress(value);
        return s.replaceAll("\\bсадоводческое\\s+некоммерческое\\s+товарищество\\b", " ")
                .replaceAll("\\bсадоводческое\\s+товарищество\\b", " ")
                .replaceAll("\\bснт\\b", " ")
                .replaceAll("\\bтерритория\\b", " ")
                .replaceAll("\\s+", " ").trim();
    }

    private boolean sntEquivalent(String input, String candidate) {
        String a = normalizeSntName(input);
        String b = normalizeSntName(candidate);
        if (a.isEmpty() || b.isEmpty()) return false;
        return b.equals(a) || b.contains(a) || a.contains(b);
    }

    private AddressParts parseAddressParts(String original, String configuredCity) {
        String s = original.toLowerCase(java.util.Locale.ROOT).replace('ё', 'е').trim();
        String lower = s;
        String cityLower = configuredCity.toLowerCase(java.util.Locale.ROOT);
        if (lower.startsWith(cityLower + ",")) s = s.substring(configuredCity.length()).replaceFirst("^\\s*,\\s*", "").trim();

        String microdistrict = "";
        // Поддерживаем нумерованные и именные микрорайоны:
        // "1-й микрорайон", "мкр 1", "микрорайон Заречье",
        // "мкр Заречье" и "Заречье микрорайон".
        java.util.regex.Matcher mm = java.util.regex.Pattern
                .compile("(?i)(?:^|[,;])\\s*(\\d+)\\s*(?:-й|-я)?\\s*(?:микрорайон|мкр\\.?)\\b")
                .matcher(s);
        if (mm.find()) {
            microdistrict = mm.group(1) + " микрорайон";
        } else {
            java.util.regex.Matcher named = java.util.regex.Pattern
                    .compile("(?i)(?:^|[,;])\\s*(?:микрорайон|мкр\\.?)\\s*([^,;]+?)(?=\\s*(?:,|;|(?:д\\.?|дом|участок|уч\\.?)\\s*\\d|\\d+[а-я]?(?:$|\\s)))")
                    .matcher(s);
            if (named.find()) {
                String name = named.group(1).trim();
                name = name.replaceFirst("(?i)\\s*(?:,?\\s*)(?:д\\.?|дом|участок|уч\\.?)\\s*\\d+[а-я]?(?:[-/]\\d+[а-я]?)?.*$", "").trim();
                name = name.replaceFirst("(?i)\\s+\\d+[а-я]?$", "").trim();
                if (!name.isEmpty()) microdistrict = name;
            } else {
                java.util.regex.Matcher suffix = java.util.regex.Pattern
                        .compile("(?i)(?:^|[,;])\\s*([^,;]+?)\\s*(?:микрорайон|мкр\\.?)\\s*(?:,|$)")
                        .matcher(s);
                if (suffix.find()) {
                    microdistrict = suffix.group(1).trim() + " микрорайон";
                } else if (normalizeAddress(configuredCity).equals("егорьевск")) {
                    // В Егорьевске Заречье и Лесной являются именно микрорайонами,
                    // поэтому разрешаем и короткий ввод: "Заречье, 25Б" /
                    // "Лесной, 2-4к2" без слова "микрорайон".
                    java.util.regex.Matcher known = java.util.regex.Pattern
                            .compile("(?i)(?:^|[,;])\\s*(заречье|лесной)\\s*(?=(?:,|;|д\\.?|дом|участок|уч\\.?|\\d|$))")
                            .matcher(s);
                    if (known.find()) microdistrict = known.group(1).trim();
                }
            }
        }

        String sntName = "";
        java.util.regex.Matcher snt = java.util.regex.Pattern
                .compile("(?i)(?:^|[,;])\\s*(?:снт|садоводческое\\s+(?:некоммерческое\\s+)?товарищество|садовое\\s+товарищество|территория\\s+снт)\\s*([^,;]+?)(?=\\s*(?:,|;|(?:д\\.?|дом|участок|уч\\.?)\\s*\\d|\\d+[а-я]?(?:$|\\s)))")
                .matcher(s);
        if (snt.find()) {
            sntName = snt.group(1).trim()
                    .replace("«", "").replace("»", "").replace("\"", "")
                    .replaceFirst("(?i)\\s*(?:д\\.?|дом|участок|уч\\.?)\\s*\\d+[а-я]?(?:[-/]\\d+[а-я]?)?.*$", "")
                    .replaceFirst("(?i)\\s+\\d+[а-я]?\\s*$", "")
                    .trim();
            sntName = sntName.replaceFirst("(?i)\\s+территория\\s*$", "").trim();
        }
        if (sntName.isEmpty()) {
            java.util.regex.Matcher sntLoose = java.util.regex.Pattern
                    .compile("(?i)(?:^|[,;])\\s*(?:снт|садоводческое\\s+(?:некоммерческое\\s+)?товарищество|садовое\\s+товарищество)\\s+([^,;]+)")
                    .matcher(s);
            if (sntLoose.find()) {
                sntName = sntLoose.group(1).trim()
                        .replaceFirst("(?i)\\s*(?:д\\.?|дом|участок|уч\\.?)\\s*\\d+.*$", "")
                        .replaceFirst("(?i)\\s+\\d+[а-я]?\\s*$", "")
                        .trim();
                sntName = sntName.replaceFirst("(?i)\\s+территория\\s*$", "").trim();
            }
        }

        String house = "";
        java.util.regex.Matcher hm = java.util.regex.Pattern
                .compile("(?i)(?:(?:д\\.?|дом|участок|уч\\.?)\\s*)?(\\d+[а-я]?(?:[-/]\\d+[а-я]?)?(?:к\\d+[а-я]?)?)(?=\\s*(?:$|[,;]))")
                .matcher(s);
        if (hm.find()) house = hm.group(1);
        else {
            java.util.regex.Matcher hm2 = java.util.regex.Pattern.compile("(?:^|[ ,])(#?\\d+[а-я]?(?:[-/]\\d+[а-я]?)?(?:к\\d+[а-я]?)?)(?:$|[ ,])", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(s);
            while (hm2.find()) house = hm2.group(1).replace("#", "");
        }

        String locality = "";
        java.util.regex.Matcher lm = java.util.regex.Pattern
                .compile("(?i)(?:деревня|д\\.?|село|пос\\.?|поселок|п\\.г\\.т\\.|пгт)\\s+([^,]+)")
                .matcher(s);
        if (lm.find() && !lm.group(1).trim().matches("\\d+[а-я]?")) locality = lm.group(1).trim();

        String withoutHouse = s.replaceAll("(?i)(?:,?\\s*)(?:д\\.?|дом)\\s*\\d+[а-я]?(?:\\/\\d+)?", "").trim();
        withoutHouse = withoutHouse.replaceAll("(?i)(?:,?\\s*)\\d+[а-я]?(?:[-/]\\d+[а-я]?)?(?:к\\d+[а-я]?)?\\s*$", "").trim();
        String street = withoutHouse;
        if (!locality.isEmpty()) {
            street = street.replaceFirst("(?i)(?:деревня|д\\.?|село|пос\\.?|поселок|п\\.г\\.т\\.|пгт)\\s+" + java.util.regex.Pattern.quote(locality), "").trim();
        }
        street = street.replaceAll("^,+|,+$", "").trim();
        if (street.equalsIgnoreCase(configuredCity)) street = "";
        if (!sntName.isEmpty()) {
            // Не отправляем название СНТ как обычную улицу. Оно будет
            // использоваться отдельным фильтром и в нескольких поисковых запросах.
            street = "";
        }

        // For a village address, Pelias structured search works best with the
        // house number as address and the village as locality.
        return new AddressParts(house, locality, street, microdistrict, sntName);
    }

    private String extractLocality(String normalized) {
        String s = normalized == null ? "" : normalized;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(?:деревня|село|поселок|пгт)\\s+([^,]+)").matcher(s);
        return m.find() ? m.group(1).trim() : s;
    }

    private static class AddressParts {
        final String house, locality, street, microdistrict, sntName;
        AddressParts(String h, String l, String s, String m) {
            this(h, l, s, m, "");
        }
        AddressParts(String h, String l, String s, String m, String sn) {
            house = h == null ? "" : h;
            locality = l == null ? "" : l;
            street = s == null ? "" : s;
            microdistrict = m == null ? "" : m;
            sntName = sn == null ? "" : sn;
        }
        String addressForStructured() {
            if (!street.isEmpty() && !street.equalsIgnoreCase(microdistrict)) {
                return street + (house.isEmpty() ? "" : " " + house);
            }
            return house;
        }
    }

    private Point confirmCandidateBlocking(final String enteredAddress, final List<GeoCandidate> candidates) throws Exception {
        if (candidates == null || candidates.isEmpty()) return null;

        final java.util.concurrent.CountDownLatch latch = new java.util.concurrent.CountDownLatch(1);
        final GeoCandidate[] selected = new GeoCandidate[1];

        runOnUiThread(() -> {
            LinearLayout content = new LinearLayout(MainActivity.this);
            content.setOrientation(LinearLayout.VERTICAL);
            content.setPadding(dp(16), 0, dp(16), 0);

            TextView entered = text("🔎 " + enteredAddress, 16, true);
            entered.setPadding(0, dp(4), 0, dp(8));
            content.addView(entered, matchWrap());

            TextView hint = text(
                    "Выбери именно нужный дом. Как в навигаторе: сначала точный адрес, " +
                    "затем по нему строится маршрут по автомобильным дорогам.",
                    13, false);
            hint.setPadding(0, 0, 0, dp(8));
            content.addView(hint, matchWrap());

            ScrollView scroll = new ScrollView(MainActivity.this);
            LinearLayout list = new LinearLayout(MainActivity.this);
            list.setOrientation(LinearLayout.VERTICAL);

            final AlertDialog[] dialogRef = new AlertDialog[1];

            for (int i = 0; i < candidates.size(); i++) {
                final GeoCandidate candidate = candidates.get(i);

                LinearLayout card = new LinearLayout(MainActivity.this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(dp(12), dp(9), dp(12), dp(9));
                card.setBackgroundResource(android.R.drawable.dialog_holo_light_frame);

                String title = candidate.shortAddress();
                if (title == null || title.trim().isEmpty()) title = candidate.label;

                TextView main = text("📍 " + title, 15, true);
                main.setTextIsSelectable(false);
                card.addView(main, matchWrap());

                String secondary = candidate.label;
                if (!secondary.equals(title)) {
                    TextView sub = text(secondary, 12, false);
                    sub.setPadding(dp(22), dp(2), 0, 0);
                    card.addView(sub, matchWrap());
                }

                if (!candidate.house.isEmpty()) {
                    TextView exact = text("🏠 Дом " + candidate.house + " • точка здания" +
                            (candidate.confidence > 0 ? " • точность " +
                                    String.format(java.util.Locale.US, "%.0f%%", candidate.confidence * 100) : ""), 12, false);
                    exact.setPadding(dp(22), dp(3), 0, 0);
                    card.addView(exact, matchWrap());
                }

                card.setOnClickListener(v -> {
                    selected[0] = candidate;
                    latch.countDown();
                    if (dialogRef[0] != null) dialogRef[0].dismiss();
                });

                LinearLayout.LayoutParams cp = matchWrap();
                cp.setMargins(0, 0, 0, dp(7));
                list.addView(card, cp);
            }

            scroll.addView(list);
            content.addView(scroll, new LinearLayout.LayoutParams(-1, dp(390)));

            AlertDialog dialog = new AlertDialog.Builder(MainActivity.this)
                    .setTitle("📍 Куда едем?")
                    .setView(content)
                    .setNegativeButton("Отмена", (d, which) -> latch.countDown())
                    .create();

            dialogRef[0] = dialog;
            dialog.setOnDismissListener(d -> latch.countDown());
            dialog.show();
        });

        latch.await();
        if (selected[0] == null) return null;
        return new Point(selected[0].lat, selected[0].lon);
    }

    private static class GeoCandidate {
        final String label;
        final String house;
        final String street;
        final String neighbourhood;
        final String locality;
        final String city;
        final String region;
        final String layer;
        final double confidence;
        final String accuracy;
        final String matchType;
        final double lat, lon;

        GeoCandidate(String label, String house, String street, String neighbourhood, String locality,
                     String city, String region, String layer, double confidence, String accuracy,
                     String matchType, double lat, double lon) {
            this.label = label == null ? "" : label;
            this.house = house == null ? "" : house;
            this.street = street == null ? "" : street;
            this.neighbourhood = neighbourhood == null ? "" : neighbourhood;
            this.locality = locality == null ? "" : locality;
            this.city = city == null ? "" : city;
            this.region = region == null ? "" : region;
            this.layer = layer == null ? "" : layer;
            this.confidence = confidence;
            this.accuracy = accuracy == null ? "" : accuracy;
            this.matchType = matchType == null ? "" : matchType;
            this.lat = lat;
            this.lon = lon;
        }

        String shortAddress() {
            if (!street.isEmpty() && !house.isEmpty()) return street + ", " + house;
            if (!neighbourhood.isEmpty() && !house.isEmpty()) return neighbourhood + ", " + house;
            if (!locality.isEmpty() && !house.isEmpty()) return locality + ", " + house;
            return label;
        }

        boolean isHouse() {
            return "address".equalsIgnoreCase(layer) || !house.isEmpty();
        }

        boolean isSntLike(String wantedSnt) {
            String hay = (label + " " + neighbourhood + " " + locality + " " + street)
                    .toLowerCase(java.util.Locale.ROOT).replace('ё', 'е');
            String a = wantedSnt == null ? "" : wantedSnt.toLowerCase(java.util.Locale.ROOT).replace('ё', 'е')
                    .replaceAll("\\bснт\\b", " ").replaceAll("\\bтерритория\\b", " ")
                    .replaceAll("\\s+", " ").trim();
            String b = hay.replaceAll("\\bснт\\b", " ").replaceAll("\\bтерритория\\b", " ")
                    .replaceAll("\\s+", " ").trim();
            if (a.isEmpty() || b.isEmpty()) return false;
            if (b.equals(a) || b.contains(a) || a.contains(b)) return true;
            String[] tokens = a.split("\\s+");
            int matched = 0;
            for (String t : tokens) if (t.length() >= 3 && b.contains(t)) matched++;
            return matched >= Math.max(1, tokens.length / 2);
        }
    }

    private static class ScoredCandidate {
        final GeoCandidate candidate;
        final int score;
        ScoredCandidate(GeoCandidate candidate, int score) {
            this.candidate = candidate;
            this.score = score;
        }
    }

    private String normalizeAddress(String value) {
        String s = value == null ? "" : value.toLowerCase(java.util.Locale.ROOT);
        s = s.replace('ё', 'е');
        s = s.replace("ё", "е");
        s = s.replace("-й", " ");
        s = s.replace("-я", " ");
        s = s.replace("-е", " ");
        s = s.replace("мкр.", " микрорайон ");
        s = s.replace("мкр", " микрорайон ");
        s = s.replace("микрорайон", " микрорайон ");
        s = s.replace("д.", " ");
        s = s.replace("дом", " ");
        s = s.replace("улица", " ");
        s = s.replace("ул.", " ");
        s = s.replace("проспект", " ");
        s = s.replace("просп.", " ");
        s = s.replace("просп", " ");
        s = s.replace("пр-т", " ");
        s = s.replace("пр-т.", " ");
        s = s.replace("садоводческое некоммерческое товарищество", " ");
        s = s.replace("садоводческое товарищество", " ");
        s = s.replace("снт", " ");
        s = s.replace("территория", " ");
        // «шоссе» часто отсутствует/сокращается в данных геокодера.
        // Для сравнения адресов считаем «Коломенское шоссе» и
        // «Коломенское» одним названием дороги. Сам поисковый запрос
        // при этом сохраняет исходное полное название.
        s = s.replace("шоссе", " ");
        s = s.replace("ш.", " ");
        s = s.replaceAll("\\bш\\b", " ");
        s = s.replaceAll("[^a-zа-я0-9]+", " ");
        return s.trim().replaceAll("\\s+", " ");
    }

    private String extractHouseNumber(String normalized) {
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("(?:^|\\s)(\\d+[а-я]?)(?:\\s|$)")
                .matcher(normalized);
        String last = "";
        while (m.find()) last = m.group(1);
        return last;
    }

    private String extractMicrodistrict(String normalized) {
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("(?:^|\\s)(\\d+)\\s+микрорайон(?:\\s|$)")
                .matcher(normalized);
        return m.find() ? m.group(1) + " микрорайон" : "";
    }

    private boolean microdistrictEquivalent(String inputMicro, String candidate) {
        if (inputMicro == null || inputMicro.trim().isEmpty() || candidate == null) return false;

        String input = normalizeAddress(inputMicro);
        String value = normalizeAddress(candidate);
        if (input.isEmpty() || value.isEmpty()) return false;

        // Сравниваем без слова "микрорайон", поскольку Pelias может
        // вернуть neighbourhood как просто "Заречье".
        String bareInput = input.replaceAll("\\s+микрорайон\\b", "").trim();
        String bareValue = value.replaceAll("\\s+микрорайон\\b", "").trim();
        if (bareInput.isEmpty()) return false;

        if (bareValue.equals(bareInput)) return true;
        if (value.matches(".*\\b" + java.util.regex.Pattern.quote(bareInput) + "\\b.*")) return true;
        return bareValue.contains(bareInput) || bareInput.contains(bareValue);
    }

    private String extractStreetPart(String normalized) {
        String s = normalized.replaceAll("\\b\\d+\\s+микрорайон\\b", "").trim();
        s = s.replaceAll("\\b\\d+[а-я]?\\b", " ").trim();
        return s.replaceAll("\\s+", " ").trim();
    }

    private void showRouteAlternatives(final Order order) {
        String key = getOrsKey();
        if (key.isEmpty()) {
            toast("❌ В APK не встроен API-ключ");
            return;
        }

        final AlertDialog loading = new AlertDialog.Builder(this)
                .setTitle("🗺️ Варианты маршрута")
                .setMessage("🔄 Ищу варианты проезда по автомобильным дорогам…")
                .setNegativeButton("Закрыть", null)
                .create();
        loading.show();

        executor.execute(() -> {
            try {
                Store store = findStore(order.storeName);
                if (store == null) throw new Exception("Магазин не найден");

                Point start = new Point(store.lat, store.lon);
                int idx = orders.indexOf(order);
                if (idx > 0 && isSameMultiChain(orders.get(idx - 1), order)) {
                    Order prev = orders.get(idx - 1);
                    start = new Point(prev.lat, prev.lon);
                }

                List<Route> alternatives = routeAlternatives(start.lat, start.lon, order.lat, order.lon, key);
                final Point routeStart = start;
                runOnUiThread(() -> {
                    try { loading.dismiss(); } catch (Exception ignored) {}
                    showRouteAlternativesDialog(order, routeStart, alternatives);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    try { loading.dismiss(); } catch (Exception ignored) {}
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("❌ Не удалось получить маршруты")
                            .setMessage(safeMessage(e))
                            .setPositiveButton("OK", null)
                            .show();
                });
            }
        });
    }

    private void showRouteAlternativesDialog(final Order order, final Point start, final List<Route> routes) {
        if (routes.isEmpty()) {
            toast("❌ Варианты маршрута не найдены");
            return;
        }

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), 0, dp(20), 0);
        box.addView(text("🚗 Варианты рассчитаны по автомобильным дорогам. Выбери подходящий и при необходимости открой его в навигаторе.", 13, false), matchWrap());

        for (int i = 0; i < routes.size(); i++) {
            final Route r = routes.get(i);
            final int number = i + 1;
            Button b = button("Маршрут " + number + " — " + km(r.km) + " км • " + r.minutes + " мин");
            b.setOnClickListener(v -> {
                openNavigator(start, order.lat, order.lon);
                toast("🧭 Открываю маршрут " + number + ". Навигатор может предложить свои варианты дороги.");
            });
            box.addView(b, matchWrap());
        }

        new AlertDialog.Builder(this)
                .setTitle("🗺️ " + routes.size() + " варианта маршрута")
                .setView(box)
                .setNegativeButton("Закрыть", null)
                .show();
    }

    private List<Route> routeAlternatives(double slat, double slon, double dlat, double dlon, String key) throws Exception {
        URL u = new URL(ORS_ROUTING_BASE + "/v2/directions/driving-car/json");
        HttpURLConnection c = (HttpURLConnection) u.openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(15000);
        c.setReadTimeout(20000);
        c.setDoOutput(true);
        c.setRequestProperty("Authorization", key);
        c.setRequestProperty("Content-Type", "application/json");

        JSONObject body = new JSONObject();
        JSONArray coords = new JSONArray();
        coords.put(new JSONArray().put(slon).put(slat));
        coords.put(new JSONArray().put(dlon).put(dlat));
        body.put("coordinates", coords);
        body.put("instructions", false);
        body.put("alternative_routes", new JSONObject()
                .put("target_count", 3)
                .put("share_factor", 0.6)
                .put("weight_factor", 1.4));

        try (OutputStream os = c.getOutputStream()) {
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }

        JSONObject root = new JSONObject(read(c));
        JSONArray routes = root.optJSONArray("routes");
        if (routes == null || routes.length() == 0) return Collections.emptyList();

        List<Route> result = new ArrayList<>();
        for (int i = 0; i < routes.length(); i++) {
            JSONObject summary = routes.getJSONObject(i).getJSONObject("summary");
            result.add(new Route(summary.getDouble("distance") / 1000.0,
                    (int) Math.round(summary.getDouble("duration") / 60.0)));
        }
        return result;
    }

    private Route route(double slat, double slon, double dlat, double dlon, String key) throws Exception {
        URL u = new URL(ORS_ROUTING_BASE + "/v2/directions/driving-car/json");
        HttpURLConnection c = (HttpURLConnection) u.openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(15000);
        c.setReadTimeout(20000);
        c.setDoOutput(true);
        c.setRequestProperty("Authorization", key);
        c.setRequestProperty("Content-Type", "application/json");

        JSONObject body = new JSONObject();
        JSONArray coords = new JSONArray();
        coords.put(new JSONArray().put(slon).put(slat));
        coords.put(new JSONArray().put(dlon).put(dlat));
        body.put("coordinates", coords);
        body.put("instructions", false);

        try (OutputStream os = c.getOutputStream()) {
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }

        String response = read(c);
        JSONObject root = new JSONObject(response);
        JSONObject summary = root.getJSONArray("routes").getJSONObject(0).getJSONObject("summary");
        return new Route(summary.getDouble("distance") / 1000.0, (int) Math.round(summary.getDouble("duration") / 60.0));
    }

    private String httpGet(String url, String key) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod("GET");
        c.setConnectTimeout(15000);
        c.setReadTimeout(20000);
        c.setRequestProperty("Authorization", key);
        return read(c);
    }

    private String read(HttpURLConnection c) throws Exception {
        int code = c.getResponseCode();
        InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        if (in == null) throw new Exception("API " + code + " (нет ответа от сервера)");
        StringBuilder sb = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
        }
        if (code < 200 || code >= 300) {
            String body = sb.toString().trim();
            if (body.length() > 500) body = body.substring(0, 500) + "…";
            throw new Exception("API " + code + (body.isEmpty() ? "" : ": " + body));
        }
        return sb.toString();
    }

    private Point routeStartForOrder(Order order) {
        Store store = findStore(order.storeName);
        if (store == null) return new Point(0, 0);
        int idx = orders.indexOf(order);
        if (idx > 0 && isSameMultiChain(orders.get(idx - 1), order)) {
            Order prev = orders.get(idx - 1);
            return new Point(prev.lat, prev.lon);
        }
        return new Point(store.lat, store.lon);
    }

    private void openNavigator(Point start, double lat, double lon) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("yandexnavi://build_route_on_map?lat_from=" + start.lat + "&lon_from=" + start.lon + "&lat_to=" + lat + "&lon_to=" + lon));
            i.setPackage("ru.yandex.yandexnavi");
            startActivity(i);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://yandex.ru/maps/?rtext=" + start.lat + "," + start.lon + "~" + lat + "," + lon + "&rtt=auto")));
            } catch (Exception ignored) {
                toast("❌ Не удалось открыть навигатор");
            }
        }
    }

    private void loadOrders() {
        orders.clear();
        String raw = prefs.getString(ORDERS, "");
        if (raw == null || raw.trim().isEmpty()) return;
        try {
            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < a.length(); i++) {
                try {
                    JSONObject o = a.getJSONObject(i);
                    double total = o.optDouble("total", Double.NaN);
                    double km = o.optDouble("km", -1);
                    int minutes = o.optInt("minutes", -1);
                    if (!Double.isFinite(total)) {
                        double oldAmount = o.optDouble("amount", -1);
                        double oldBonus = o.optDouble("bonus", 0);
                        if (oldAmount > 0) total = oldAmount + Math.max(0, oldBonus);
                    }
                    if (Double.isFinite(total) && total >= 0 && km >= 0 && minutes >= 0) {
                        double savedRating = o.has("rating") ? o.optDouble("rating", rating) : rating;
                        double savedBonus = o.has("ratingBonus") ? o.optDouble("ratingBonus", ratingBonus(savedRating)) : 0;
                        orders.add(new Order(total, km, minutes, o.optLong("timestamp", 0),
                                o.optString("storeName", ""), o.optString("address", ""),
                                o.optDouble("lat", 0), o.optDouble("lon", 0), savedRating, savedBonus, o.optBoolean("isMulti", false), o.optBoolean("multiFirst", true)));
                    }
                } catch (Exception ignored) { }
            }
        } catch (Exception ignored) { }
    }

    private void saveOrders() {
        JSONArray a = new JSONArray();
        for (Order o : orders) {
            try {
                JSONObject j = new JSONObject();
                j.put("total", o.total);
                j.put("km", o.km);
                j.put("minutes", o.minutes);
                j.put("timestamp", o.timestamp);
                j.put("storeName", o.storeName);
                j.put("address", o.address);
                j.put("lat", o.lat);
                j.put("lon", o.lon);
                j.put("rating", o.rating);
                j.put("ratingBonus", o.ratingBonus);
                j.put("isMulti", o.isMulti);
                j.put("multiFirst", o.multiFirst);
                a.put(j);
            } catch (Exception ignored) { }
        }
        prefs.edit().putString(ORDERS, a.toString()).apply();
    }

    private EditText field(String hint, boolean decimal) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setInputType(decimal
                ? InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL
                : InputType.TYPE_CLASS_TEXT);
        e.setPadding(0, dp(8), 0, dp(8));
        return e;
    }

    private String money(double v) { return moneyFormat.format(v); }
    private String km(double v) { return kmFormat.format(v); }
    private String ratingText(double v) { return String.format(java.util.Locale.US, "%.2f", v); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    private static double parseNonNegative(String v, double fallback) {
        try {
            double n = Double.parseDouble(v == null ? "" : v.trim().replace(',', '.'));
            return Double.isFinite(n) && n >= 0 ? n : fallback;
        } catch (Exception e) { return fallback; }
    }

    private static double parseNumber(String v, double fallback) {
        try {
            double n = Double.parseDouble(v == null ? "" : v.trim().replace(',', '.'));
            return Double.isFinite(n) ? n : fallback;
        } catch (Exception e) { return fallback; }
    }

    private static double clamp(double v, double min, double max) { return Math.max(min, Math.min(max, v)); }
    private String safeMessage(Exception e) { return e.getMessage() == null ? "неизвестная ошибка" : e.getMessage(); }

    private TextView text(String v, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(v);
        t.setTextSize(size);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        return b;
    }

    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(-1, -2); }
    private LinearLayout.LayoutParams weightWrap(float w) { return new LinearLayout.LayoutParams(0, -2, w); }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private static class Store {
        final String name, address;
        final double lat, lon;
        Store(String n, String a, double la, double lo) { name = n; address = a; lat = la; lon = lo; }
    }

    private static class Point {
        final double lat, lon;
        Point(double la, double lo) { lat = la; lon = lo; }
    }

    private static class Route {
        final double km;
        final int minutes;
        Route(double k, int m) { km = k; minutes = m; }
    }

    private static class Order {
        final double total, km;
        final int minutes;
        final long timestamp;
        final String storeName, address;
        final double lat, lon, rating, ratingBonus;
        final boolean isMulti, multiFirst;

        Order(double total, double km, int minutes, long timestamp, String storeName, String address,
              double lat, double lon, double rating, double ratingBonus, boolean isMulti, boolean multiFirst) {
            this.total = total;
            this.km = km;
            this.minutes = minutes;
            this.timestamp = timestamp;
            this.storeName = storeName;
            this.address = address;
            this.lat = lat;
            this.lon = lon;
            this.rating = rating;
            this.ratingBonus = ratingBonus;
            this.isMulti = isMulti;
            this.multiFirst = multiFirst;
        }
    }
}
