package ru.courier.money;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String PREFS = "courier_money";
    private static final String ORDERS = "orders";
    private static final String ORS_KEY = "ors_key";
    private static final String BASE_ORDER = "base_order";
    private static final String PRICE_PER_KM = "price_per_km";
    private static final String RATING = "rating";
    private static final String RATING_5 = "rating_5";
    private static final String RATING_475 = "rating_475";
    private static final String RATING_450 = "rating_450";
    private static final String RATING_425 = "rating_425";
    private static final String ORS_ROUTING_BASE = "https://api.heigit.org/openrouteservice";
    private static final String ORS_GEOCODE_BASE = "https://api.heigit.org/pelias/v1";

    private final List<Order> orders = new ArrayList<>();
    private final DecimalFormat moneyFormat = new DecimalFormat("0.##");
    private final DecimalFormat kmFormat = new DecimalFormat("0.##");
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;
    private LinearLayout orderContainer;
    private TextView summary;

    private double baseOrder;
    private double pricePerKm;
    private double rating;
    private double rating5;
    private double rating475;
    private double rating450;
    private double rating425;

    private static final Store[] STORES = new Store[]{
            new Store("Пятёрочка №1", "проспект Ленина, 20", 55.371106, 39.058016),
            new Store("Пятёрочка №2", "4-й микрорайон, 21А", 55.364266, 39.061747),
            new Store("Пятёрочка №3", "ул. Спортивная, 15Б", 55.369144, 39.074362)
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        loadTariff();
        loadOrders();
        buildUi();
        refreshUi();
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }

    private void loadTariff() {
        baseOrder = parseNonNegative(prefs.getString(BASE_ORDER, "175"), 175);
        pricePerKm = parseNonNegative(prefs.getString(PRICE_PER_KM, "30"), 30);
        rating = clamp(parseNumber(prefs.getString(RATING, "5.0"), 5.0), 0, 5);
        rating5 = parseNonNegative(prefs.getString(RATING_5, "25"), 25);
        rating475 = parseNonNegative(prefs.getString(RATING_475, "20"), 20);
        rating450 = parseNonNegative(prefs.getString(RATING_450, "10"), 10);
        rating425 = parseNonNegative(prefs.getString(RATING_425, "5"), 5);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(12), dp(16), dp(12));

        root.addView(text("🚴 Courier Money", 26, true), matchWrap());
        root.addView(text("💰 Учёт заработка курьера", 15, false), matchWrap());

        summary = text("", 18, true);
        summary.setPadding(0, dp(12), 0, dp(12));
        root.addView(summary, matchWrap());

        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER_VERTICAL);

        Button add = button("➕ Заказ");
        add.setOnClickListener(v -> showAddDialog());
        controls.addView(add, weightWrap(1));

        Button settings = button("⚙️ Настройки");
        settings.setOnClickListener(v -> showSettingsDialog());
        controls.addView(settings, weightWrap(1));

        root.addView(controls, matchWrap());

        TextView ordersTitle = text("📋 Заказы", 20, true);
        ordersTitle.setPadding(0, dp(16), 0, dp(8));
        root.addView(ordersTitle, matchWrap());

        ScrollView scroll = new ScrollView(this);
        orderContainer = new LinearLayout(this);
        orderContainer.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(orderContainer);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        setContentView(root);
    }

    private void refreshUi() {
        double total = 0;
        double km = 0;
        for (Order o : orders) {
            total += o.total;
            km += o.km;
        }

        summary.setText(
                "💵 Заработано: " + money(total) + " ₽\n" +
                "📦 Заказов: " + orders.size() + " • 🚗 " + km(km) + " км\n" +
                "⚙️ Тариф: " + money(baseOrder) + " ₽ + " + money(pricePerKm) + " ₽/км • ⭐ " + ratingText(rating)
        );

        orderContainer.removeAllViews();
        List<Order> reversed = new ArrayList<>(orders);
        Collections.reverse(reversed);

        if (reversed.isEmpty()) {
            TextView empty = text("📭 Пока нет заказов.\nНажми «➕ Заказ», чтобы добавить первый.", 16, false);
            empty.setPadding(dp(4), dp(12), dp(4), dp(12));
            orderContainer.addView(empty, matchWrap());
            return;
        }

        for (Order o : reversed) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(14), dp(12), dp(14), dp(12));
            card.setBackgroundResource(android.R.drawable.dialog_holo_light_frame);

            TextView amount = text("💰 " + money(o.total) + " ₽", 20, true);
            card.addView(amount, matchWrap());
            card.addView(text("🏪 " + o.storeName, 15, true), matchWrap());
            card.addView(text("📍 " + o.address, 15, false), matchWrap());
            card.addView(text("🚗 " + km(o.km) + " км  •  ⏱️ " + o.minutes + " мин", 15, false), matchWrap());
            card.addView(text("⭐ Рейтинг " + ratingText(o.rating) + "  •  доплата " + money(o.ratingBonus) + " ₽", 14, false), matchWrap());

            LinearLayout.LayoutParams cp = matchWrap();
            cp.setMargins(0, 0, 0, dp(8));
            orderContainer.addView(card, cp);

            if (o.lat != 0 && o.lon != 0) {
                Button nav = button("🧭 Открыть маршрут в Яндекс Навигаторе");
                nav.setOnClickListener(v -> openNavigator(o.lat, o.lon));
                orderContainer.addView(nav, cp);
            }
        }
    }

    private void showAddDialog() {
        final LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), 0, dp(20), 0);

        TextView selected = text("🏪 Выбери магазин", 17, true);
        box.addView(selected, matchWrap());
        final Store[] chosen = {null};

        for (Store s : STORES) {
            Button b = button("🏪 " + s.name + "\n" + s.address);
            b.setOnClickListener(v -> {
                chosen[0] = s;
                selected.setText("✅ " + s.name + "\n" + s.address);
            });
            box.addView(b, matchWrap());
        }

        EditText address = field("📍 Адрес клиента", false);
        address.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        box.addView(address, matchWrap());

        TextView tariffInfo = text(
                "💵 " + money(baseOrder) + " ₽ за заказ\n" +
                "🚗 " + money(pricePerKm) + " ₽ за 1 км\n" +
                "⭐ Рейтинг " + ratingText(rating) + " → +" + money(ratingBonus(rating)) + " ₽",
                14, false);
        tariffInfo.setPadding(0, dp(8), 0, dp(8));
        box.addView(tariffInfo, matchWrap());

        TextView status = text("Нажми «Рассчитать» — приложение найдёт адрес и построит маршрут.", 13, false);
        status.setPadding(0, dp(8), 0, dp(8));
        box.addView(status, matchWrap());

        final android.app.AlertDialog dialog = new android.app.AlertDialog.Builder(this)
                .setTitle("➕ Добавить заказ")
                .setView(box)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Рассчитать", null)
                .create();

        dialog.setOnShowListener(ignored -> dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            if (chosen[0] == null) {
                toast("🏪 Выбери магазин");
                return;
            }

            String addr = address.getText().toString().trim();
            if (addr.isEmpty()) {
                toast("📍 Введи адрес клиента");
                return;
            }

            String key = getOrsKey();
            if (key.isEmpty()) {
                dialog.dismiss();
                showSettingsDialog();
                toast("🔑 Сначала добавь API-ключ OpenRouteService");
                return;
            }

            dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setEnabled(false);
            status.setText("🔄 Ищу адрес и рассчитываю маршрут…");

            executor.execute(() -> {
                try {
                    Point dest = geocode(addr, key);
                    if (dest == null) throw new Exception("Адрес не найден");
                    Route r = route(chosen[0].lat, chosen[0].lon, dest.lat, dest.lon, key);
                    double rb = ratingBonus(rating);
                    double total = baseOrder + r.km * pricePerKm + rb;

                    Order order = new Order(
                            total, r.km, r.minutes, System.currentTimeMillis(),
                            chosen[0].name, addr, dest.lat, dest.lon,
                            rating, rb
                    );

                    runOnUiThread(() -> {
                        orders.add(order);
                        saveOrders();
                        refreshUi();
                        dialog.dismiss();
                        toast("✅ Заказ добавлен: " + money(total) + " ₽");
                    });
                } catch (Exception e) {
                    runOnUiThread(() -> {
                        dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                        status.setText("❌ Ошибка: " + safeMessage(e));
                    });
                }
            });
        }));

        dialog.show();
    }

    private String getOrsKey() {
        String saved = prefs.getString(ORS_KEY, "");
        if (saved != null && !saved.trim().isEmpty()) return saved.trim();
        return BuildConfig.ORS_API_KEY == null ? "" : BuildConfig.ORS_API_KEY.trim();
    }

    private double ratingBonus(double r) {
        if (r >= 5.0) return rating5;
        if (r >= 4.75) return rating475;
        if (r >= 4.50) return rating450;
        if (r >= 4.25) return rating425;
        return 0;
    }

    private void showSettingsDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), 0, dp(20), 0);

        TextView tariffTitle = text("💰 Тариф", 18, true);
        tariffTitle.setPadding(0, dp(4), 0, dp(6));
        box.addView(tariffTitle, matchWrap());

        EditText base = field("Стоимость заказа, ₽", true);
        base.setText(money(baseOrder));
        box.addView(base, matchWrap());

        EditText perKm = field("Цена за 1 км, ₽", true);
        perKm.setText(money(pricePerKm));
        box.addView(perKm, matchWrap());

        EditText currentRating = field("Текущий рейтинг (0–5)", true);
        currentRating.setText(ratingText(rating));
        box.addView(currentRating, matchWrap());

        TextView ratingTitle = text("⭐ Доплата за рейтинг", 18, true);
        ratingTitle.setPadding(0, dp(10), 0, dp(6));
        box.addView(ratingTitle, matchWrap());

        EditText r5 = field("⭐ 5.0 → ₽", true); r5.setText(money(rating5)); box.addView(r5, matchWrap());
        EditText r475 = field("⭐ 4.75–4.99 → ₽", true); r475.setText(money(rating475)); box.addView(r475, matchWrap());
        EditText r450 = field("⭐ 4.50–4.74 → ₽", true); r450.setText(money(rating450)); box.addView(r450, matchWrap());
        EditText r425 = field("⭐ 4.25–4.49 → ₽", true); r425.setText(money(rating425)); box.addView(r425, matchWrap());

        TextView below = text("⭐ Ниже 4.25 → 0 ₽", 14, false);
        below.setPadding(0, dp(4), 0, dp(10));
        box.addView(below, matchWrap());

        TextView routeTitle = text("🧭 Маршрутизация", 18, true);
        routeTitle.setPadding(0, dp(4), 0, dp(6));
        box.addView(routeTitle, matchWrap());

        EditText apiKey = field("🔑 API-ключ OpenRouteService", false);
        apiKey.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        apiKey.setText(getOrsKey());
        box.addView(apiKey, matchWrap());

        TextView note = text("Расстояние считается точно, без округления. Время — без учёта пробок.", 12, false);
        note.setPadding(0, dp(6), 0, dp(4));
        box.addView(note, matchWrap());

        new android.app.AlertDialog.Builder(this)
                .setTitle("⚙️ Настройки")
                .setView(box)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("💾 Сохранить", (d, w) -> {
                    double newBase = parseNonNegative(base.getText().toString(), -1);
                    double newPerKm = parseNonNegative(perKm.getText().toString(), -1);
                    double newRating = parseNumber(currentRating.getText().toString(), -1);
                    double new5 = parseNonNegative(r5.getText().toString(), -1);
                    double new475 = parseNonNegative(r475.getText().toString(), -1);
                    double new450 = parseNonNegative(r450.getText().toString(), -1);
                    double new425 = parseNonNegative(r425.getText().toString(), -1);

                    if (newBase < 0 || newPerKm < 0 || newRating < 0 || newRating > 5 ||
                            new5 < 0 || new475 < 0 || new450 < 0 || new425 < 0) {
                        toast("❌ Проверь значения тарифа и рейтинга");
                        return;
                    }

                    baseOrder = newBase;
                    pricePerKm = newPerKm;
                    rating = newRating;
                    rating5 = new5;
                    rating475 = new475;
                    rating450 = new450;
                    rating425 = new425;

                    prefs.edit()
                            .putString(BASE_ORDER, Double.toString(baseOrder))
                            .putString(PRICE_PER_KM, Double.toString(pricePerKm))
                            .putString(RATING, Double.toString(rating))
                            .putString(RATING_5, Double.toString(rating5))
                            .putString(RATING_475, Double.toString(rating475))
                            .putString(RATING_450, Double.toString(rating450))
                            .putString(RATING_425, Double.toString(rating425))
                            .putString(ORS_KEY, apiKey.getText().toString().trim().isEmpty()
                                    ? BuildConfig.ORS_API_KEY
                                    : apiKey.getText().toString().trim())
                            .apply();

                    refreshUi();
                    toast("✅ Настройки сохранены");
                })
                .show();
    }

    private Point geocode(String address, String key) throws Exception {
        String q = URLEncoder.encode(address + ", Егорьевск, Московская область, Россия", StandardCharsets.UTF_8.name());
        String url = ORS_GEOCODE_BASE + "/search?text=" + q + "&size=1";
        JSONObject root = new JSONObject(httpGet(url, key));
        JSONArray feats = root.optJSONArray("features");
        if (feats == null || feats.length() == 0) return null;
        JSONArray c = feats.getJSONObject(0).getJSONObject("geometry").getJSONArray("coordinates");
        return new Point(c.getDouble(1), c.getDouble(0));
    }

    private Route route(double slat, double slon, double dlat, double dlon, String key) throws Exception {
        URL u = new URL(ORS_ROUTING_BASE + "/v2/directions/driving-car/json");
        HttpURLConnection c = (HttpURLConnection) u.openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(15000);
        c.setReadTimeout(20000);
        c.setDoOutput(true);
        c.setRequestProperty("Authorization", key);
        c.setRequestProperty("Content-Type", "application/json");

        JSONObject body = new JSONObject();
        JSONArray coords = new JSONArray();
        coords.put(new JSONArray().put(slon).put(slat));
        coords.put(new JSONArray().put(dlon).put(dlat));
        body.put("coordinates", coords);
        body.put("instructions", false);

        try (OutputStream os = c.getOutputStream()) {
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }

        String response = read(c);
        JSONObject root = new JSONObject(response);
        JSONObject summary = root.getJSONArray("routes").getJSONObject(0).getJSONObject("summary");
        return new Route(summary.getDouble("distance") / 1000.0, (int) Math.round(summary.getDouble("duration") / 60.0));
    }

    private String httpGet(String url, String key) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod("GET");
        c.setConnectTimeout(15000);
        c.setReadTimeout(20000);
        c.setRequestProperty("Authorization", key);
        return read(c);
    }

    private String read(HttpURLConnection c) throws Exception {
        int code = c.getResponseCode();
        InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        if (in == null) throw new Exception("API " + code + " (нет ответа от сервера)");
        StringBuilder sb = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
        }
        if (code < 200 || code >= 300) throw new Exception("API " + code + ": " + sb);
        return sb.toString();
    }

    private void openNavigator(double lat, double lon) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("yandexnavi://build_route_on_map?lat_to=" + lat + "&lon_to=" + lon));
            i.setPackage("ru.yandex.yandexnavi");
            startActivity(i);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://yandex.ru/maps/?rtext=~" + lat + "," + lon + "&rtt=auto")));
            } catch (Exception ignored) {
                toast("❌ Не удалось открыть навигатор");
            }
        }
    }

    private void loadOrders() {
        orders.clear();
        String raw = prefs.getString(ORDERS, "");
        if (raw == null || raw.trim().isEmpty()) return;
        try {
            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < a.length(); i++) {
                try {
                    JSONObject o = a.getJSONObject(i);
                    double total = o.optDouble("total", Double.NaN);
                    double km = o.optDouble("km", -1);
                    int minutes = o.optInt("minutes", -1);
                    if (!Double.isFinite(total)) {
                        double oldAmount = o.optDouble("amount", -1);
                        double oldBonus = o.optDouble("bonus", 0);
                        if (oldAmount > 0) total = oldAmount + Math.max(0, oldBonus);
                    }
                    if (Double.isFinite(total) && total >= 0 && km >= 0 && minutes >= 0) {
                        double savedRating = o.has("rating") ? o.optDouble("rating", rating) : rating;
                        double savedBonus = o.has("ratingBonus") ? o.optDouble("ratingBonus", ratingBonus(savedRating)) : 0;
                        orders.add(new Order(total, km, minutes, o.optLong("timestamp", 0),
                                o.optString("storeName", ""), o.optString("address", ""),
                                o.optDouble("lat", 0), o.optDouble("lon", 0), savedRating, savedBonus));
                    }
                } catch (Exception ignored) { }
            }
        } catch (Exception ignored) { }
    }

    private void saveOrders() {
        JSONArray a = new JSONArray();
        for (Order o : orders) {
            try {
                JSONObject j = new JSONObject();
                j.put("total", o.total);
                j.put("km", o.km);
                j.put("minutes", o.minutes);
                j.put("timestamp", o.timestamp);
                j.put("storeName", o.storeName);
                j.put("address", o.address);
                j.put("lat", o.lat);
                j.put("lon", o.lon);
                j.put("rating", o.rating);
                j.put("ratingBonus", o.ratingBonus);
                a.put(j);
            } catch (Exception ignored) { }
        }
        prefs.edit().putString(ORDERS, a.toString()).apply();
    }

    private EditText field(String hint, boolean decimal) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setInputType(decimal
                ? InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL
                : InputType.TYPE_CLASS_TEXT);
        e.setPadding(0, dp(8), 0, dp(8));
        return e;
    }

    private String money(double v) { return moneyFormat.format(v); }
    private String km(double v) { return kmFormat.format(v); }
    private String ratingText(double v) { return String.format(java.util.Locale.US, "%.2f", v); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    private static double parseNonNegative(String v, double fallback) {
        try {
            double n = Double.parseDouble(v == null ? "" : v.trim().replace(',', '.'));
            return Double.isFinite(n) && n >= 0 ? n : fallback;
        } catch (Exception e) { return fallback; }
    }

    private static double parseNumber(String v, double fallback) {
        try {
            double n = Double.parseDouble(v == null ? "" : v.trim().replace(',', '.'));
            return Double.isFinite(n) ? n : fallback;
        } catch (Exception e) { return fallback; }
    }

    private static double clamp(double v, double min, double max) { return Math.max(min, Math.min(max, v)); }
    private String safeMessage(Exception e) { return e.getMessage() == null ? "неизвестная ошибка" : e.getMessage(); }

    private TextView text(String v, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(v);
        t.setTextSize(size);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        return b;
    }

    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(-1, -2); }
    private LinearLayout.LayoutParams weightWrap(float w) { return new LinearLayout.LayoutParams(0, -2, w); }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private static class Store {
        final String name, address;
        final double lat, lon;
        Store(String n, String a, double la, double lo) { name = n; address = a; lat = la; lon = lo; }
    }

    private static class Point {
        final double lat, lon;
        Point(double la, double lo) { lat = la; lon = lo; }
    }

    private static class Route {
        final double km;
        final int minutes;
        Route(double k, int m) { km = k; minutes = m; }
    }

    private static class Order {
        final double total, km;
        final int minutes;
        final long timestamp;
        final String storeName, address;
        final double lat, lon, rating, ratingBonus;

        Order(double total, double km, int minutes, long timestamp, String storeName, String address,
              double lat, double lon, double rating, double ratingBonus) {
            this.total = total;
            this.km = km;
            this.minutes = minutes;
            this.timestamp = timestamp;
            this.storeName = storeName;
            this.address = address;
            this.lat = lat;
            this.lon = lon;
            this.rating = rating;
            this.ratingBonus = ratingBonus;
        }
    }
}
