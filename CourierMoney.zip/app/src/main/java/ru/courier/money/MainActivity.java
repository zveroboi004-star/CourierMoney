package ru.courier.money;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String PREFS = "courier_money";
    private static final String ORDERS = "orders";
    private static final String FUEL = "fuel";

    private final List<Order> orders = new ArrayList<>();
    private final DecimalFormat moneyFormat = new DecimalFormat("0.##");
    private SharedPreferences prefs;
    private LinearLayout orderContainer;
    private TextView summary;
    private double fuelPerKm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        fuelPerKm = parseNonNegative(prefs.getString(FUEL, "0"), 0);
        loadOrders();
        buildUi();
        refreshUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(12), dp(16), dp(12));

        TextView title = text("Courier Money", 26, true);
        root.addView(title, matchWrap());

        TextView subtitle = text("Учёт заработка курьера", 15, false);
        root.addView(subtitle, matchWrap());

        summary = text("", 18, true);
        summary.setPadding(0, dp(12), 0, dp(12));
        root.addView(summary, matchWrap());

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER_VERTICAL);

        Button add = button("+ Заказ");
        add.setOnClickListener(v -> showAddDialog());
        controls.addView(add, weightWrap(1));

        Button fuel = button("Топливо");
        fuel.setOnClickListener(v -> showFuelDialog());
        controls.addView(fuel, weightWrap(1));

        Button clear = button("Очистить");
        clear.setOnClickListener(v -> {
            orders.clear();
            saveOrders();
            refreshUi();
            Toast.makeText(this, "Заказы удалены", Toast.LENGTH_SHORT).show();
        });
        controls.addView(clear, weightWrap(1));

        root.addView(controls, matchWrap());

        TextView ordersTitle = text("Заказы", 20, true);
        ordersTitle.setPadding(0, dp(16), 0, dp(8));
        root.addView(ordersTitle, matchWrap());

        ScrollView scroll = new ScrollView(this);
        orderContainer = new LinearLayout(this);
        orderContainer.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(orderContainer);
        root.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
    }

    private void refreshUi() {
        double gross = 0, km = 0, hours = 0;
        for (Order o : orders) {
            gross += o.total();
            km += o.km;
            hours += o.minutes / 60.0;
        }
        double fuel = km * fuelPerKm;
        double net = gross - fuel;
        double avg = orders.isEmpty() ? 0 : gross / orders.size();
        double perKm = km > 0 ? net / km : 0;
        double perHour = hours > 0 ? net / hours : 0;

        summary.setText(
                "Сегодня: " + money(net) + " ₽\n" +
                orders.size() + " заказов • " +
                money(gross) + " ₽ валом\n" +
                "Топливо: " + money(fuel) + " ₽ (" + money(fuelPerKm) + " ₽/км)\n" +
                "Средний: " + money(avg) + " ₽ • " +
                money(perKm) + " ₽/км • " +
                money(perHour) + " ₽/час"
        );

        orderContainer.removeAllViews();
        List<Order> reversed = new ArrayList<>(orders);
        Collections.reverse(reversed);

        if (reversed.isEmpty()) {
            TextView empty = text("Пока нет заказов. Нажми «+ Заказ».", 16, false);
            orderContainer.addView(empty, matchWrap());
            return;
        }

        for (Order o : reversed) {
            TextView item = text(
                    money(o.total()) + " ₽" +
                    (o.bonus > 0 ? "  (бонус " + money(o.bonus) + " ₽)" : "") +
                    "\n" + money(o.km) + " км • " + o.minutes + " мин" +
                    "\n" + (o.minutes > 0 ? money(o.total() / (o.minutes / 60.0)) : "0") + " ₽/час",
                    16, false);
            item.setPadding(dp(12), dp(12), dp(12), dp(12));
            item.setBackgroundResource(android.R.drawable.dialog_holo_light_frame);
            LinearLayout.LayoutParams lp = matchWrap();
            lp.setMargins(0, 0, 0, dp(8));
            orderContainer.addView(item, lp);
        }
    }

    private void showAddDialog() {
        final LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), 0, dp(20), 0);

        EditText amount = field("Сумма, ₽", true);
        EditText bonus = field("Бонус/доплата, ₽", true);
        EditText km = field("Километры", true);
        EditText minutes = field("Время, минут", false);
        box.addView(amount);
        box.addView(bonus);
        box.addView(km);
        box.addView(minutes);

        final android.app.AlertDialog dialog = new android.app.AlertDialog.Builder(this)
                .setTitle("Добавить заказ")
                .setView(box)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Добавить", null)
                .create();

        dialog.setOnShowListener(ignored -> {
            dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                double a = parseNonNegative(amount.getText().toString(), -1);
                double b = parseNonNegative(bonus.getText().toString(), -1);
                double k = parseNonNegative(km.getText().toString(), -1);
                int m = parseIntNonNegative(minutes.getText().toString(), -1);

                if (a <= 0 || b < 0 || k < 0 || m < 0) {
                    Toast.makeText(this, "Проверь данные заказа", Toast.LENGTH_SHORT).show();
                    return;
                }
                orders.add(new Order(a, b, k, m, System.currentTimeMillis()));
                saveOrders();
                refreshUi();
                dialog.dismiss();
            });
        });
        dialog.show();
    }

    private void showFuelDialog() {
        EditText input = field("₽ за километр", true);
        input.setText(fuelPerKm == 0 ? "" : money(fuelPerKm));

        new android.app.AlertDialog.Builder(this)
                .setTitle("Расходы на топливо")
                .setView(input)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Сохранить", (dialog, which) -> {
                    double value = parseNonNegative(input.getText().toString(), -1);
                    if (value < 0) {
                        Toast.makeText(this, "Введите число не меньше 0", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    fuelPerKm = value;
                    prefs.edit().putString(FUEL, Double.toString(value)).apply();
                    refreshUi();
                }).show();
    }

    private EditText field(String hint, boolean decimal) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_NUMBER |
                (decimal ? InputType.TYPE_NUMBER_FLAG_DECIMAL : 0));
        e.setPadding(dp(0), dp(8), dp(0), dp(8));
        return e;
    }

    private void loadOrders() {
        orders.clear();
        String raw = prefs.getString(ORDERS, "");
        if (raw == null || raw.trim().isEmpty()) return;
        try {
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length(); i++) {
                try {
                    JSONObject o = array.getJSONObject(i);
                    double amount = o.optDouble("amount", -1);
                    double bonus = o.optDouble("bonus", -1);
                    double km = o.optDouble("km", -1);
                    int minutes = o.optInt("minutes", -1);
                    long timestamp = o.optLong("timestamp", 0);
                    if (amount > 0 && bonus >= 0 && km >= 0 && minutes >= 0) {
                        orders.add(new Order(amount, bonus, km, minutes, timestamp));
                    }
                } catch (Exception ignored) {
                    // Skip one broken order instead of losing all saved orders.
                }
            }
        } catch (Exception ignored) {
            // Corrupted storage is safely treated as an empty list.
        }
    }

    private void saveOrders() {
        JSONArray array = new JSONArray();
        for (Order o : orders) {
            try {
                JSONObject json = new JSONObject();
                json.put("amount", o.amount);
                json.put("bonus", o.bonus);
                json.put("km", o.km);
                json.put("minutes", o.minutes);
                json.put("timestamp", o.timestamp);
                array.put(json);
            } catch (Exception ignored) {
            }
        }
        prefs.edit().putString(ORDERS, array.toString()).apply();
    }

    private String money(double value) {
        return moneyFormat.format(value);
    }

    private static double parseNonNegative(String value, double fallback) {
        if (value == null) return fallback;
        try {
            double n = Double.parseDouble(value.trim().replace(',', '.'));
            return Double.isFinite(n) && n >= 0 ? n : fallback;
        } catch (Exception e) {
            return fallback;
        }
    }

    private static int parseIntNonNegative(String value, int fallback) {
        if (value == null) return fallback;
        try {
            int n = Integer.parseInt(value.trim());
            return n >= 0 ? n : fallback;
        } catch (Exception e) {
            return fallback;
        }
    }

    private TextView text(String value, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        return b;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams weightWrap(float weight) {
        return new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, weight);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static class Order {
        final double amount, bonus, km;
        final int minutes;
        final long timestamp;

        Order(double amount, double bonus, double km, int minutes, long timestamp) {
            this.amount = amount;
            this.bonus = bonus;
            this.km = km;
            this.minutes = minutes;
            this.timestamp = timestamp;
        }

        double total() {
            return amount + bonus;
        }
    }
}
