# Courier Money — стабильная версия

Простой Android-калькулятор заработка курьера без сервера и без бэкенда.

## Функции
- добавление заказов;
- сумма заказа и бонус/доплата;
- километры и время;
- общий заработок;
- чистый заработок с учётом топлива;
- ₽/км и ₽/час;
- хранение данных локально на телефоне;
- удаление всех заказов.

## Сборка
Проект специально сделан без Jetpack Compose, Kotlin Gradle Plugin, DataStore и сторонних библиотек.
Это уменьшает количество точек отказа при облачной сборке.

Совместимая связка:
- Android Gradle Plugin 9.0.1
- Gradle 9.1.0
- Java 17
- compileSdk 36
- targetSdk 36
- minSdk 23

Если используешь существующий GitHub Actions workflow, он может запускать:
`gradle --no-daemon --stacktrace assembleDebug`

APK:
`app/build/outputs/apk/debug/app-debug.apk`
