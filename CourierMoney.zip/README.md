# Courier Money V2

Личный калькулятор заработка курьера на Android.

## Что есть
- сохранение заказов на телефоне через Jetpack DataStore;
- бонусы и доплаты;
- расчёт чистого заработка;
- стоимость топлива на километр;
- ₽/км и ₽/час после расходов;
- оценка выгодности заказа;
- сборка debug APK через GitHub Actions.

## Сборка
Проект использует Android Gradle Plugin 9.0.1, Gradle 9.1 и Java 17.

В GitHub открой **Actions → Build Courier Money APK → Run workflow**.
После успешной сборки APK будет доступен в артефактах workflow.
