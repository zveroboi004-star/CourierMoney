# Courier Money

Version 1.7 (versionCode 6).

The Android module is `app`. GitHub Actions must provide the repository secret
`ORS_API_KEY` as an environment variable during the build.

Routing uses `https://api.heigit.org/openrouteservice/v2/directions/driving-car/json`.
Address search uses `https://api.heigit.org/pelias/v1/search`.

No traffic data is requested; route duration is the routing engine's estimated
travel time without live traffic.


## v1.4 checks
- API key is embedded at build time from GitHub Actions secret `ORS_API_KEY`; the app no longer asks the user to enter it.
- Geocoding uses `https://api.heigit.org/pelias/v1/search`.
- Routing uses `https://api.heigit.org/openrouteservice/v2/directions/driving-car/json`.
- GitHub Actions verifies that `:app:assembleDebug` exists before building.


## v1.7
- Separate editable pickup and delivery fees.
- Multi-order checkbox when adding an order.
- For the first order of a multi-order: pickup + delivery + route km + rating bonus.
- For following multi-orders from the same store: no pickup fee and no rating bonus; route starts at the previous client.
- Clear button resets order/statistics data while preserving tariff settings.
- Rating bonus is applied only to the first order in a multi-order chain.


v1.7: добавлено редактирование адреса заказа с автоматическим пересчётом участка и последующих участков мультизаказа.


## v2.0 — подтверждение адреса
Перед расчётом приложение показывает найденные варианты адреса. Выбор подтверждённой точки используется и для дорожного маршрута, и для кнопки навигатора.
