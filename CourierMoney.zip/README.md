# Courier Money V2

Личный калькулятор заработка курьера.

Возможности:
- сохранение заказов на телефоне через Jetpack DataStore;
- бонусы/доплаты;
- чистый заработок;
- стоимость топлива на км;
- ₽/км и ₽/час после расходов;
- оценка выгодности заказа.

## Сборка APK через GitHub Actions

В репозитории открой **Actions → Build Courier Money APK → Run workflow**.
После успешной сборки APK находится в артефакте **CourierMoney-APK**.

Проект использует Android Gradle Plugin 9.0.1, Kotlin/Compose plugin 2.3.21 и Gradle 9.1.
