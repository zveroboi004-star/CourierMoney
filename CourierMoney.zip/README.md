CourierMoney v2.4 — добавлены варианты автомобильных маршрутов: кнопка «🗺️ Маршруты» показывает до 3 вариантов ORS с расстоянием и временем, а затем позволяет открыть направление в навигаторе.

# Courier Money

Version 1.7 (versionCode 6).

The Android module is `app`. GitHub Actions must provide the repository secret
`ORS_API_KEY` as an environment variable during the build.

Routing uses `https://api.heigit.org/openrouteservice/v2/directions/driving-car/json`.
Address search uses `https://api.heigit.org/pelias/v1/search`.

No traffic data is requested; route duration is the routing engine's estimated
travel time without live traffic.


## v1.4 checks
- API key is embedded at build time from GitHub Actions secret `ORS_API_KEY`; the app no longer asks the user to enter it.
- Geocoding uses `https://api.heigit.org/pelias/v1/search`.
- Routing uses `https://api.heigit.org/openrouteservice/v2/directions/driving-car/json`.
- GitHub Actions verifies that `:app:assembleDebug` exists before building.


## v1.7
- Separate editable pickup and delivery fees.
- Multi-order checkbox when adding an order.
- For the first order of a multi-order: pickup + delivery + route km + rating bonus.
- For following multi-orders from the same store: no pickup fee and no rating bonus; route starts at the previous client.
- Clear button resets order/statistics data while preserving tariff settings.
- Rating bonus is applied only to the first order in a multi-order chain.


v1.7: добавлено редактирование адреса заказа с автоматическим пересчётом участка и последующих участков мультизаказа.


## v2.0 — подтверждение адреса
Перед расчётом приложение показывает найденные варианты адреса. Выбор подтверждённой точки используется и для дорожного маршрута, и для кнопки навигатора.


## v2.4 — поиск адреса по принципу навигатора
- По умолчанию к адресу автоматически добавляется город из настроек.
- При указанном номере дома поиск допускает только точные объекты слоя `address` с совпадающим номером дома.
- Город фильтруется по структурированным полям Pelias (`city`/`locality`) и не определяется только по почтовому индексу.
- В подтверждении адреса показывается основной адрес, полный адрес геокодера и отдельная отметка «Дом N».
- После выбора конкретной точки именно её координаты используются для расчёта маршрута по автомобильным дорогам и для навигатора.
- Варианты маршрута сохраняются через `alternative_routes`.
- Это поведение имитирует принцип навигатора: «адрес → точный объект → координаты → маршрут», но геокодирование выполняет OpenRouteService/Pelias, а не коммерческий геокодер Яндекса.
## Что исправлено в версии 2.5

- Поиск домов переработан: для микрорайонов используется отдельное поле `neighbourhood`, а номер дома передаётся отдельно.
- Для одного адреса выполняется несколько вариантов поиска, чтобы корректно находить записи вроде `Егорьевск, 1-й микрорайон, д.39`.
- В результатах допускаются только адреса из города, указанного в настройках.
- Для конкретного дома по-прежнему запрещены результаты уровня города, индекса или одной улицы.
- В подтверждении показывается найденный дом и оценка уверенности геокодера, если она есть.
- Маршрутизация остаётся `driving-car` через openrouteservice; расстояние выводится с точностью 0,1 км.
- API `api.heigit.org` используется как актуальный адрес ORS.
