# Courier Money

Version 1.3 (versionCode 4).

The Android module is `app`. GitHub Actions must provide the repository secret
`ORS_API_KEY` as an environment variable during the build.

Routing uses `https://api.heigit.org/openrouteservice/v2/directions/driving-car/json`.
Address search uses `https://api.heigit.org/pelias/v1/search`.

No traffic data is requested; route duration is the routing engine's estimated
travel time without live traffic.


## v1.4 checks
- API key is embedded at build time from GitHub Actions secret `ORS_API_KEY`; the app no longer asks the user to enter it.
- Geocoding uses `https://api.heigit.org/pelias/v1/search`.
- Routing uses `https://api.heigit.org/openrouteservice/v2/directions/driving-car/json`.
- GitHub Actions verifies that `:app:assembleDebug` exists before building.
